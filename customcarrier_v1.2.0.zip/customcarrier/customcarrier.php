<?php
/**
 * Custom Carrier Module for PrestaShop 8.x
 *
 * Dynamically calculates shipping costs based on product-level rules.
 *
 * @author Norwit
 * @copyright 2024 Norwit
 * @license AFL-3.0
 */

declare(strict_types=1);

if (!defined('_PS_VERSION_')) {
    exit;
}

// Load module classes
require_once __DIR__ . '/src/Entity/CustomCarrierProduct.php';
require_once __DIR__ . '/src/Repository/CustomCarrierProductRepository.php';
require_once __DIR__ . '/src/Service/ShippingCalculator.php';

class CustomCarrier extends CarrierModule
{
    /** @var string */
    public $id_carrier;

    /** @var array */
    protected const HOOKS = [
        'displayAdminProductsShippingStepBottom',
        'actionProductUpdate',
        'actionProductAdd',
        'displayBackOfficeHeader',
        'updateCarrier',
    ];

    /** @var array */
    protected const CONFIG_KEYS = [
        'CUSTOMCARRIER_ACTIVE',
        'CUSTOMCARRIER_NAME',
        'CUSTOMCARRIER_ID_CARRIER',
        'CUSTOMCARRIER_DEFAULT_COST',
        'CUSTOMCARRIER_POLAND_ZONE_ID',
        'CUSTOMCARRIER_FREE_SHIPPING_ONLY_POLAND',
    ];

    public function __construct()
    {
        $this->name = 'customcarrier';
        $this->tab = 'shipping_logistics';
        $this->version = '1.2.0';
        $this->author = 'Norwit';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '8.0.0', 'max' => _PS_VERSION_];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->trans('Custom Carrier', [], 'Modules.Customcarrier.Admin');
        $this->description = $this->trans(
            'Dynamic shipping cost calculation based on product-level rules.',
            [],
            'Modules.Customcarrier.Admin'
        );
        $this->confirmUninstall = $this->trans(
            'Are you sure you want to uninstall this module?',
            [],
            'Modules.Customcarrier.Admin'
        );
    }

    /**
     * Module installation
     */
    public function install(): bool
    {
        if (!parent::install()) {
            return false;
        }

        // Register hooks
        foreach (self::HOOKS as $hook) {
            if (!$this->registerHook($hook)) {
                return false;
            }
        }

        // Install database tables
        if (!$this->installDatabase()) {
            return false;
        }

        // Create carrier
        if (!$this->createCarrier()) {
            return false;
        }

        // Set default configuration
        Configuration::updateValue('CUSTOMCARRIER_ACTIVE', 1);
        Configuration::updateValue('CUSTOMCARRIER_NAME', 'Wysyłka kurierem');
        Configuration::updateValue('CUSTOMCARRIER_DEFAULT_COST', 15.00);
        Configuration::updateValue('CUSTOMCARRIER_POLAND_ZONE_ID', 0);
        Configuration::updateValue('CUSTOMCARRIER_FREE_SHIPPING_ONLY_POLAND', 0);

        // Install admin tab for bulk settings
        if (!$this->installTab()) {
            return false;
        }

        return true;
    }

    /**
     * Module uninstallation
     */
    public function uninstall(): bool
    {
        // Uninstall admin tab
        $this->uninstallTab();

        // Delete carrier
        $this->deleteCarrier();

        // Uninstall database tables
        $this->uninstallDatabase();

        // Remove configuration
        foreach (self::CONFIG_KEYS as $key) {
            Configuration::deleteByName($key);
        }

        return parent::uninstall();
    }

    /**
     * Install admin tab for bulk settings
     */
    private function installTab(): bool
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'AdminCustomCarrierBulk';
        $tab->name = [];

        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'Custom Carrier Bulk';
        }

        $tab->id_parent = (int) Tab::getIdFromClassName('AdminCatalog');
        $tab->module = $this->name;

        return $tab->add();
    }

    /**
     * Uninstall admin tab
     */
    private function uninstallTab(): bool
    {
        $idTab = (int) Tab::getIdFromClassName('AdminCustomCarrierBulk');
        if ($idTab) {
            $tab = new Tab($idTab);
            return $tab->delete();
        }
        return true;
    }

    /**
     * Install database tables
     */
    protected function installDatabase(): bool
    {
        $sqlFile = dirname(__FILE__) . '/sql/install.sql';
        if (!file_exists($sqlFile)) {
            return false;
        }

        $sql = file_get_contents($sqlFile);
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);

        // Remove SQL comments
        $sql = preg_replace('/--.*$/m', '', $sql);
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);

        // Fallback for older MySQL versions without utf8mb4 support
        $mysqlVersion = Db::getInstance()->getValue('SELECT VERSION()');
        if (version_compare($mysqlVersion, '5.5.3', '<')) {
            $sql = str_replace('utf8mb4', 'utf8', $sql);
            $sql = str_replace('utf8_unicode_ci', 'utf8_general_ci', $sql);
        }

        // Split by semicolon (handles various line ending formats)
        $queries = preg_split('/;\s*/', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query) && !preg_match('/^[\s]*$/', $query)) {
                try {
                    if (!Db::getInstance()->execute($query)) {
                        PrestaShopLogger::addLog(
                            'CustomCarrier install error: ' . Db::getInstance()->getMsgError(),
                            3,
                            null,
                            'CustomCarrier'
                        );
                        return false;
                    }
                } catch (Exception $e) {
                    PrestaShopLogger::addLog(
                        'CustomCarrier install exception: ' . $e->getMessage(),
                        3,
                        null,
                        'CustomCarrier'
                    );
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Uninstall database tables
     */
    protected function uninstallDatabase(): bool
    {
        $sqlFile = dirname(__FILE__) . '/sql/uninstall.sql';
        if (!file_exists($sqlFile)) {
            return true;
        }

        $sql = file_get_contents($sqlFile);
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);

        // Remove SQL comments
        $sql = preg_replace('/--.*$/m', '', $sql);

        // Split by semicolon (handles various line ending formats)
        $queries = preg_split('/;\s*/', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query) && !preg_match('/^[\s]*$/', $query)) {
                try {
                    Db::getInstance()->execute($query);
                } catch (Exception $e) {
                    // Log but continue - uninstall should not fail
                    PrestaShopLogger::addLog(
                        'CustomCarrier uninstall warning: ' . $e->getMessage(),
                        2,
                        null,
                        'CustomCarrier'
                    );
                }
            }
        }

        return true;
    }

    /**
     * Create the carrier
     */
    protected function createCarrier(): bool
    {
        $carrier = new Carrier();
        $carrier->name = Configuration::get('CUSTOMCARRIER_NAME') ?: 'Wysyłka kurierem';
        $carrier->active = true;
        $carrier->deleted = false;
        $carrier->shipping_handling = false;
        $carrier->range_behavior = 0;
        $carrier->is_module = true;
        $carrier->is_free = false;
        $carrier->shipping_external = true;
        $carrier->need_range = true;
        $carrier->external_module_name = $this->name;
        $carrier->shipping_method = Carrier::SHIPPING_METHOD_PRICE;

        // Set delay for all languages
        $languages = Language::getLanguages(false);
        $delay = [];
        foreach ($languages as $language) {
            $delay[$language['id_lang']] = $this->trans('1-3 business days', [], 'Modules.Customcarrier.Shop');
        }
        $carrier->delay = $delay;

        if (!$carrier->add()) {
            return false;
        }

        // Assign carrier to all groups
        $groups = Group::getGroups(true);
        foreach ($groups as $group) {
            Db::getInstance()->insert('carrier_group', [
                'id_carrier' => (int) $carrier->id,
                'id_group' => (int) $group['id_group'],
            ]);
        }

        // Create price range
        $rangePrice = new RangePrice();
        $rangePrice->id_carrier = (int) $carrier->id;
        $rangePrice->delimiter1 = 0;
        $rangePrice->delimiter2 = 10000;
        $rangePrice->add();

        // Create weight range
        $rangeWeight = new RangeWeight();
        $rangeWeight->id_carrier = (int) $carrier->id;
        $rangeWeight->delimiter1 = 0;
        $rangeWeight->delimiter2 = 10000;
        $rangeWeight->add();

        // Assign carrier to all zones
        $zones = Zone::getZones(true);
        foreach ($zones as $zone) {
            Db::getInstance()->insert('carrier_zone', [
                'id_carrier' => (int) $carrier->id,
                'id_zone' => (int) $zone['id_zone'],
            ]);

            // Create delivery entry for price range
            Db::getInstance()->insert('delivery', [
                'id_carrier' => (int) $carrier->id,
                'id_range_price' => (int) $rangePrice->id,
                'id_range_weight' => null,
                'id_zone' => (int) $zone['id_zone'],
                'price' => 0,
            ]);
        }

        // Save carrier ID in configuration
        Configuration::updateValue('CUSTOMCARRIER_ID_CARRIER', (int) $carrier->id);

        // Copy logo
        $logoSource = dirname(__FILE__) . '/logo.png';
        if (file_exists($logoSource)) {
            copy($logoSource, _PS_SHIP_IMG_DIR_ . '/' . (int) $carrier->id . '.jpg');
        }

        return true;
    }

    /**
     * Delete the carrier
     */
    protected function deleteCarrier(): bool
    {
        $idCarrier = (int) Configuration::get('CUSTOMCARRIER_ID_CARRIER');
        if ($idCarrier) {
            $carrier = new Carrier($idCarrier);
            if (Validate::isLoadedObject($carrier)) {
                $carrier->deleted = true;
                $carrier->save();
            }
        }

        return true;
    }

    /**
     * Calculate shipping cost for cart
     *
     * @param Cart $cart The cart object
     * @param float $shippingCost Base shipping cost from PrestaShop
     * @return float|false Shipping cost or false if not available
     */
    public function getOrderShippingCost($cart, $shippingCost)
    {
        if (!Configuration::get('CUSTOMCARRIER_ACTIVE')) {
            return false;
        }

        if (!Validate::isLoadedObject($cart)) {
            return false;
        }

        $products = $cart->getProducts();
        if (empty($products)) {
            // Return default cost for empty cart so carrier is visible
            $defaultCost = (float) Configuration::get('CUSTOMCARRIER_DEFAULT_COST');
            return $defaultCost > 0 ? $defaultCost : 0.0;
        }

        // Get zone for threshold calculation
        $idZone = (int) $cart->id_address_delivery
            ? (int) Address::getZoneById($cart->id_address_delivery)
            : (int) Configuration::get('PS_ZONE_DEFAULT');

        $zoneThreshold = $this->getZoneThreshold($idZone);

        // Check if free shipping is only for Poland
        $polandZoneId = (int) Configuration::get('CUSTOMCARRIER_POLAND_ZONE_ID');
        $freeShippingOnlyPoland = (bool) Configuration::get('CUSTOMCARRIER_FREE_SHIPPING_ONLY_POLAND');
        $isPolandZone = ($polandZoneId > 0 && $idZone === $polandZoneId);

        // If free shipping only for Poland and current zone is not Poland, disable threshold
        if ($freeShippingOnlyPoland && !$isPolandZone) {
            $zoneThreshold = 0;
        }

        // Calculate totals for threshold products
        $thresholdProductsTotal = 0.0;
        foreach ($products as $product) {
            $settings = $this->getProductTransportSettings((int) $product['id_product']);
            if (!empty($settings['apply_threshold'])) {
                $thresholdProductsTotal += (float) $product['total_wt'];
            }
        }

        // Check if threshold is met
        $thresholdMet = ($zoneThreshold > 0 && $thresholdProductsTotal >= $zoneThreshold);

        // Shipping cost logic:
        // - separate_package = ON: sum costs (each product ships separately)
        // - multiply_by_quantity = ON: sum costs (each unit adds to shipping)
        // - Both OFF: take only the highest cost (all fit in one package)
        $summedCosts = 0.0;
        $standardPackageCosts = [];

        foreach ($products as $product) {
            $settings = $this->getProductTransportSettings((int) $product['id_product']);
            $productCost = $this->calculateProductShippingCost(
                (int) $product['id_product'],
                (int) $product['cart_quantity'],
                $thresholdMet,
                $isPolandZone,
                $freeShippingOnlyPoland
            );

            // Sum costs if: separate_package OR multiply_by_quantity is enabled
            if (!empty($settings['separate_package']) || !empty($settings['multiply_by_quantity'])) {
                $summedCosts += $productCost;
            } else {
                // Standard package - collect costs, will take highest
                $standardPackageCosts[] = $productCost;
            }
        }

        // For standard products, take only the highest shipping cost (one package)
        $maxStandardCost = !empty($standardPackageCosts) ? max($standardPackageCosts) : 0.0;

        return $summedCosts + $maxStandardCost;
    }

    /**
     * Calculate shipping cost for external calls
     *
     * @param array $params Parameters
     * @return float|false
     */
    public function getOrderShippingCostExternal($params)
    {
        // Delegate to main method
        $cart = $params['cart'] ?? null;
        if (!$cart) {
            return false;
        }

        return $this->getOrderShippingCost($cart, 0);
    }

    /**
     * Calculate shipping cost for a single product
     *
     * @param int $idProduct Product ID
     * @param int $quantity Quantity in cart
     * @param bool $thresholdMet Whether zone threshold is met
     * @param bool $isPolandZone Whether current zone is Poland
     * @param bool $freeShippingOnlyPoland Whether free shipping is limited to Poland
     */
    protected function calculateProductShippingCost(
        int $idProduct,
        int $quantity,
        bool $thresholdMet = false,
        bool $isPolandZone = true,
        bool $freeShippingOnlyPoland = false
    ): float {
        $settings = $this->getProductTransportSettings($idProduct);
        $defaultCost = (float) Configuration::get('CUSTOMCARRIER_DEFAULT_COST');

        // No custom settings - use default cost from module configuration
        if (empty($settings)) {
            return $defaultCost;
        }

        // Check if product is excluded from free shipping
        $excludedFromFreeShipping = !empty($settings['exclude_from_free_shipping']);

        // Free shipping - unconditional (but check exclusion and Poland restriction)
        if (!empty($settings['free_shipping'])) {
            // If product excluded from free shipping, skip
            if ($excludedFromFreeShipping) {
                // Continue to calculate cost
            } elseif ($freeShippingOnlyPoland && !$isPolandZone) {
                // Free shipping only for Poland, but not in Poland zone - skip free shipping
            } else {
                return 0.0;
            }
        }

        // Quantity threshold - free shipping when quantity >= threshold
        $freeShippingQuantity = (int) ($settings['free_shipping_quantity'] ?? 0);
        if ($freeShippingQuantity > 0 && $quantity >= $freeShippingQuantity) {
            if (!$excludedFromFreeShipping) {
                if (!$freeShippingOnlyPoland || $isPolandZone) {
                    return 0.0;
                }
            }
        }

        // Zone threshold met - free shipping for products with apply_threshold enabled
        // But NOT for separate_package products - they always pay
        // And NOT for excluded products
        if ($thresholdMet && !empty($settings['apply_threshold']) && empty($settings['separate_package'])) {
            if (!$excludedFromFreeShipping) {
                return 0.0;
            }
        }

        $baseCost = (float) ($settings['base_shipping_cost'] ?? 0.0);

        // NEW: Max quantity per package logic
        $maxQuantityPerPackage = isset($settings['max_quantity_per_package']) ? (int) $settings['max_quantity_per_package'] : 0;

        if ($maxQuantityPerPackage > 0) {
            // Calculate number of packages needed
            $packageCount = (int) ceil($quantity / $maxQuantityPerPackage);

            // Check for max packages limit and alternative cost
            $maxPackages = isset($settings['max_packages']) ? (int) $settings['max_packages'] : 0;
            $costAboveMaxPackages = isset($settings['cost_above_max_packages']) ? (float) $settings['cost_above_max_packages'] : null;

            // If max packages limit is set and exceeded, use alternative cost
            if ($maxPackages > 0 && $packageCount > $maxPackages && $costAboveMaxPackages !== null && $costAboveMaxPackages > 0) {
                // Exceeded max packages limit → use alternative single package cost
                return $costAboveMaxPackages;
            }

            // Otherwise multiply base cost by number of packages
            return $baseCost * $packageCount;
        }

        // Multiply by quantity if enabled
        if (!empty($settings['multiply_by_quantity'])) {
            return $baseCost * $quantity;
        }

        return $baseCost;
    }

    /**
     * Get transport settings for a product
     */
    public function getProductTransportSettings(int $idProduct): array
    {
        $sql = new DbQuery();
        $sql->select('*');
        $sql->from('customcarrier_product');
        $sql->where('id_product = ' . (int) $idProduct);

        $result = Db::getInstance()->getRow($sql);

        return $result ?: [];
    }

    /**
     * Get zone threshold for free shipping
     */
    public function getZoneThreshold(int $idZone): float
    {
        $sql = new DbQuery();
        $sql->select('threshold_amount');
        $sql->from('customcarrier_zone');
        $sql->where('id_zone = ' . (int) $idZone);
        $sql->where('active = 1');

        $result = Db::getInstance()->getValue($sql);

        return $result ? (float) $result : 0.0;
    }

    /**
     * Save zone threshold
     */
    public function saveZoneThreshold(int $idZone, float $amount): bool
    {
        $exists = $this->getZoneThreshold($idZone) > 0 || $this->zoneThresholdExists($idZone);

        $fields = [
            'id_zone' => (int) $idZone,
            'threshold_amount' => (float) $amount,
            'active' => 1,
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        if (!$exists) {
            $fields['date_add'] = date('Y-m-d H:i:s');
            return Db::getInstance()->insert('customcarrier_zone', $fields);
        }

        return Db::getInstance()->update(
            'customcarrier_zone',
            $fields,
            'id_zone = ' . (int) $idZone
        );
    }

    /**
     * Check if zone threshold record exists
     */
    protected function zoneThresholdExists(int $idZone): bool
    {
        $sql = new DbQuery();
        $sql->select('id_customcarrier_zone');
        $sql->from('customcarrier_zone');
        $sql->where('id_zone = ' . (int) $idZone);

        return (bool) Db::getInstance()->getValue($sql);
    }

    /**
     * Get all zone thresholds
     */
    public function getAllZoneThresholds(): array
    {
        $sql = new DbQuery();
        $sql->select('cz.*, z.name as zone_name');
        $sql->from('customcarrier_zone', 'cz');
        $sql->leftJoin('zone', 'z', 'z.id_zone = cz.id_zone');

        $results = Db::getInstance()->executeS($sql);

        $thresholds = [];
        if ($results) {
            foreach ($results as $row) {
                $thresholds[(int) $row['id_zone']] = $row;
            }
        }

        return $thresholds;
    }

    /**
     * Save transport settings for a product
     */
    public function saveProductTransportSettings(int $idProduct, array $data): bool
    {
        $exists = $this->getProductTransportSettings($idProduct);

        $fields = [
            'id_product' => (int) $idProduct,
            'free_shipping' => !empty($data['free_shipping']) ? 1 : 0,
            'base_shipping_cost' => (float) ($data['base_shipping_cost'] ?? 0),
            'multiply_by_quantity' => !empty($data['multiply_by_quantity']) ? 1 : 0,
            'free_shipping_quantity' => (int) ($data['free_shipping_quantity'] ?? 0),
            'apply_threshold' => !empty($data['apply_threshold']) ? 1 : 0,
            'separate_package' => !empty($data['separate_package']) ? 1 : 0,
            'exclude_from_free_shipping' => !empty($data['exclude_from_free_shipping']) ? 1 : 0,
            'max_quantity_per_package' => isset($data['max_quantity_per_package']) ? (int) $data['max_quantity_per_package'] : null,
            'max_packages' => isset($data['max_packages']) ? (int) $data['max_packages'] : null,
            'cost_above_max_packages' => isset($data['cost_above_max_packages']) ? (float) $data['cost_above_max_packages'] : null,
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        if (empty($exists)) {
            $fields['date_add'] = date('Y-m-d H:i:s');
            return Db::getInstance()->insert('customcarrier_product', $fields);
        }

        return Db::getInstance()->update(
            'customcarrier_product',
            $fields,
            'id_product = ' . (int) $idProduct
        );
    }

    /**
     * Hook: Update carrier ID when carrier is updated
     */
    public function hookUpdateCarrier(array $params): void
    {
        $idCarrierOld = (int) $params['id_carrier'];
        $idCarrierNew = (int) $params['carrier']->id;

        if ($idCarrierOld === (int) Configuration::get('CUSTOMCARRIER_ID_CARRIER')) {
            Configuration::updateValue('CUSTOMCARRIER_ID_CARRIER', $idCarrierNew);
        }
    }

    /**
     * Hook: Display transport settings on product page (Shipping tab)
     */
    public function hookDisplayAdminProductsShippingStepBottom(array $params): string
    {
        $idProduct = (int) ($params['id_product'] ?? 0);
        $settings = $this->getProductTransportSettings($idProduct);

        // Get default currency sign
        $defaultCurrency = Currency::getDefaultCurrency();
        $currencySign = $defaultCurrency ? $defaultCurrency->sign : 'zł';

        $this->context->smarty->assign([
            'customcarrier_settings' => $settings,
            'customcarrier_id_product' => $idProduct,
            'customcarrier_currency_sign' => $currencySign,
        ]);

        return $this->display(__FILE__, 'views/templates/admin/product_tab.tpl');
    }

    /**
     * Hook: Save product transport settings after product update
     */
    public function hookActionProductUpdate(array $params): void
    {
        $this->saveProductFromPost($params);
    }

    /**
     * Hook: Save product transport settings after product add
     */
    public function hookActionProductAdd(array $params): void
    {
        $this->saveProductFromPost($params);
    }

    /**
     * Save product transport settings from POST data
     */
    protected function saveProductFromPost(array $params): void
    {
        // Get product ID from params or POST
        $idProduct = 0;

        if (isset($params['id_product'])) {
            $idProduct = (int) $params['id_product'];
        } elseif (isset($params['product']) && $params['product'] instanceof Product) {
            $idProduct = (int) $params['product']->id;
        }

        if ($idProduct <= 0) {
            return;
        }

        // Check if our fields were submitted
        if (!Tools::getIsset('customcarrier_free_shipping')) {
            return;
        }

        $this->saveProductTransportSettings($idProduct, [
            'free_shipping' => (int) Tools::getValue('customcarrier_free_shipping'),
            'base_shipping_cost' => (float) Tools::getValue('customcarrier_base_shipping_cost'),
            'multiply_by_quantity' => (int) Tools::getValue('customcarrier_multiply_by_quantity'),
            'free_shipping_quantity' => (int) Tools::getValue('customcarrier_free_shipping_quantity'),
            'apply_threshold' => (int) Tools::getValue('customcarrier_apply_threshold'),
            'separate_package' => (int) Tools::getValue('customcarrier_separate_package'),
            'exclude_from_free_shipping' => (int) Tools::getValue('customcarrier_exclude_from_free_shipping'),
            'max_quantity_per_package' => Tools::getValue('customcarrier_max_quantity_per_package') ? (int) Tools::getValue('customcarrier_max_quantity_per_package') : null,
            'max_packages' => Tools::getValue('customcarrier_max_packages') ? (int) Tools::getValue('customcarrier_max_packages') : null,
            'cost_above_max_packages' => Tools::getValue('customcarrier_cost_above_max_packages') ? (float) Tools::getValue('customcarrier_cost_above_max_packages') : null,
        ]);
    }

    /**
     * Hook: Load CSS/JS in back office
     */
    public function hookDisplayBackOfficeHeader(): string
    {
        $controller = Tools::getValue('controller');

        if ($controller === 'AdminProducts') {
            $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
        }

        if ($controller === 'AdminCustomCarrierBulk') {
            $this->context->controller->addCSS($this->_path . 'views/css/bulk_shipping.css');
        }

        return '';
    }

    /**
     * Module configuration page
     */
    public function getContent(): string
    {
        $output = '';

        // Link to bulk settings page
        $bulkLink = $this->context->link->getAdminLink('AdminCustomCarrierBulk');
        $output .= '<div class="alert alert-info">'
            . '<i class="icon-truck"></i> '
            . $this->trans('Bulk edit shipping settings for multiple products:', [], 'Modules.Customcarrier.Admin')
            . ' <a href="' . $bulkLink . '" class="btn btn-default btn-sm">'
            . '<i class="icon-list"></i> '
            . $this->trans('Open Bulk Settings', [], 'Modules.Customcarrier.Admin')
            . '</a></div>';

        // Handle main form submission
        if (Tools::isSubmit('submitCustomCarrierConfig')) {
            $carrierName = Tools::getValue('CUSTOMCARRIER_NAME');
            $active = (int) Tools::getValue('CUSTOMCARRIER_ACTIVE');
            $defaultCost = (float) Tools::getValue('CUSTOMCARRIER_DEFAULT_COST');
            $polandZoneId = (int) Tools::getValue('CUSTOMCARRIER_POLAND_ZONE_ID');
            $freeShippingOnlyPoland = (int) Tools::getValue('CUSTOMCARRIER_FREE_SHIPPING_ONLY_POLAND');

            if (empty($carrierName)) {
                $output .= $this->displayError($this->trans('Carrier name is required.', [], 'Modules.Customcarrier.Admin'));
            } else {
                Configuration::updateValue('CUSTOMCARRIER_NAME', pSQL($carrierName));
                Configuration::updateValue('CUSTOMCARRIER_ACTIVE', $active);
                Configuration::updateValue('CUSTOMCARRIER_DEFAULT_COST', $defaultCost);
                Configuration::updateValue('CUSTOMCARRIER_POLAND_ZONE_ID', $polandZoneId);
                Configuration::updateValue('CUSTOMCARRIER_FREE_SHIPPING_ONLY_POLAND', $freeShippingOnlyPoland);

                // Update carrier name
                $idCarrier = (int) Configuration::get('CUSTOMCARRIER_ID_CARRIER');
                if ($idCarrier) {
                    $carrier = new Carrier($idCarrier);
                    if (Validate::isLoadedObject($carrier)) {
                        $carrier->name = pSQL($carrierName);
                        $carrier->active = (bool) $active;
                        $carrier->save();
                    }
                }

                $output .= $this->displayConfirmation($this->trans('Settings saved successfully.', [], 'Modules.Customcarrier.Admin'));
            }
        }

        // Handle zone thresholds form submission
        if (Tools::isSubmit('submitCustomCarrierZones')) {
            $zones = Zone::getZones(true);
            foreach ($zones as $zone) {
                $thresholdValue = Tools::getValue('zone_threshold_' . (int) $zone['id_zone']);
                if ($thresholdValue !== false && $thresholdValue !== '') {
                    $this->saveZoneThreshold((int) $zone['id_zone'], (float) $thresholdValue);
                }
            }
            $output .= $this->displayConfirmation($this->trans('Zone thresholds saved successfully.', [], 'Modules.Customcarrier.Admin'));
        }

        return $output . $this->renderConfigForm() . $this->renderZoneThresholdsForm();
    }

    /**
     * Render configuration form
     */
    protected function renderConfigForm(): string
    {
        // Get zones for select
        $zones = Zone::getZones(true);
        $zoneOptions = [
            ['id_zone' => 0, 'name' => '-- ' . $this->trans('Select zone', [], 'Modules.Customcarrier.Admin') . ' --'],
        ];
        foreach ($zones as $zone) {
            $zoneOptions[] = $zone;
        }

        $fields = [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Settings', [], 'Modules.Customcarrier.Admin'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => $this->trans('Enable module', [], 'Modules.Customcarrier.Admin'),
                        'name' => 'CUSTOMCARRIER_ACTIVE',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'active_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                            ['id' => 'active_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                        ],
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Carrier name', [], 'Modules.Customcarrier.Admin'),
                        'name' => 'CUSTOMCARRIER_NAME',
                        'required' => true,
                        'desc' => $this->trans('Name displayed to customers during checkout.', [], 'Modules.Customcarrier.Admin'),
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Default shipping cost', [], 'Modules.Customcarrier.Admin'),
                        'name' => 'CUSTOMCARRIER_DEFAULT_COST',
                        'required' => true,
                        'suffix' => 'zł',
                        'desc' => $this->trans('Default shipping cost for products without custom settings.', [], 'Modules.Customcarrier.Admin'),
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->trans('Poland zone', [], 'Modules.Customcarrier.Admin'),
                        'name' => 'CUSTOMCARRIER_POLAND_ZONE_ID',
                        'options' => [
                            'query' => $zoneOptions,
                            'id' => 'id_zone',
                            'name' => 'name',
                        ],
                        'desc' => $this->trans('Select which zone represents Poland for free shipping restrictions.', [], 'Modules.Customcarrier.Admin'),
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->trans('Free shipping only for Poland', [], 'Modules.Customcarrier.Admin'),
                        'name' => 'CUSTOMCARRIER_FREE_SHIPPING_ONLY_POLAND',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'poland_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                            ['id' => 'poland_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                        ],
                        'desc' => $this->trans('If enabled, free shipping (thresholds) will only apply to Poland zone. Other zones will not get free shipping.', [], 'Modules.Customcarrier.Admin'),
                    ],
                ],
                'submit' => [
                    'title' => $this->trans('Save', [], 'Admin.Actions'),
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $helper->submit_action = 'submitCustomCarrierConfig';

        $helper->fields_value = [
            'CUSTOMCARRIER_ACTIVE' => Configuration::get('CUSTOMCARRIER_ACTIVE'),
            'CUSTOMCARRIER_NAME' => Configuration::get('CUSTOMCARRIER_NAME'),
            'CUSTOMCARRIER_DEFAULT_COST' => Configuration::get('CUSTOMCARRIER_DEFAULT_COST'),
            'CUSTOMCARRIER_POLAND_ZONE_ID' => Configuration::get('CUSTOMCARRIER_POLAND_ZONE_ID'),
            'CUSTOMCARRIER_FREE_SHIPPING_ONLY_POLAND' => Configuration::get('CUSTOMCARRIER_FREE_SHIPPING_ONLY_POLAND'),
        ];

        return $helper->generateForm([$fields]);
    }

    /**
     * Render zone thresholds configuration form
     */
    protected function renderZoneThresholdsForm(): string
    {
        $zones = Zone::getZones(true);
        $thresholds = $this->getAllZoneThresholds();

        $inputs = [];
        foreach ($zones as $zone) {
            $idZone = (int) $zone['id_zone'];
            $inputs[] = [
                'type' => 'text',
                'label' => $zone['name'],
                'name' => 'zone_threshold_' . $idZone,
                'suffix' => 'zł',
                'desc' => $this->trans('Free shipping threshold for this zone. Set 0 to disable.', [], 'Modules.Customcarrier.Admin'),
            ];
        }

        $fields = [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Zone Free Shipping Thresholds', [], 'Modules.Customcarrier.Admin'),
                    'icon' => 'icon-map-marker',
                ],
                'description' => $this->trans('Set the minimum order amount for free shipping per zone. Products with "Apply zone threshold" enabled will get free shipping when the cart total exceeds this amount.', [], 'Modules.Customcarrier.Admin'),
                'input' => $inputs,
                'submit' => [
                    'title' => $this->trans('Save Zone Thresholds', [], 'Admin.Actions'),
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $helper->submit_action = 'submitCustomCarrierZones';

        // Set field values
        $fieldValues = [];
        foreach ($zones as $zone) {
            $idZone = (int) $zone['id_zone'];
            $fieldValues['zone_threshold_' . $idZone] = isset($thresholds[$idZone])
                ? (float) $thresholds[$idZone]['threshold_amount']
                : 0;
        }
        $helper->fields_value = $fieldValues;

        return $helper->generateForm([$fields]);
    }
}
