<?php

/**
 * File from http://PrestaShow.pl
 *
 * DISCLAIMER
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future.
 *
 * @author    PrestaShow.pl <kontakt@prestashow.pl>
 * @copyright Since 2014 PrestaShow.pl
 * @license   https://prestashow.pl/license
 */

require_once dirname(__FILE__) . "/../../config.php";

use Prestashow\PrestaCore\Controller\SettingsController;

class PShowEditorSettingsController extends SettingsController
{

    public $select_menu_tab = 'subtab-PShowEditorMain';

}
