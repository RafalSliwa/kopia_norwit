<?php

global $_MODULE;

$_MODULE = array();
$_MODULE['<{pshowskleleton12345}prestashop>pshowskleleton12345_82989dde7a24cdc4c55825f9fa126aa8'] = 'PShowSkleleton12345';
