<?php
/**
 * Upgrade script for Custom Carrier module v1.3.0
 * Adds price_threshold field for product price-based shipping rules
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param CustomCarrier $module
 * @return bool
 */
function upgrade_module_1_3_0($module)
{
    $db = Db::getInstance();
    $success = true;

    // Add price_threshold column to customcarrier_product table
    $columnExists = $db->executeS(
        'SHOW COLUMNS FROM `' . _DB_PREFIX_ . 'customcarrier_product` LIKE "price_threshold"'
    );

    if (empty($columnExists)) {
        $success &= $db->execute(
            'ALTER TABLE `' . _DB_PREFIX_ . 'customcarrier_product`
             ADD COLUMN `price_threshold` DECIMAL(20,6) DEFAULT NULL
             COMMENT "Ustawienia działają tylko dla produktów o cenie poniżej tego progu"
             AFTER `cost_above_max_packages`'
        );
    }

    return (bool) $success;
}
