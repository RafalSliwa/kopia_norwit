<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once dirname(__FILE__) . '/../../config/config.inc.php';

header('Content-Type: application/json');

try {
    $db = Db::getInstance();

    // If cart_id provided, use it
    $cartId = isset($_GET['cart_id']) ? (int)$_GET['cart_id'] : 0;

    // Show wizard price ranges
    if (isset($_GET['wizard'])) {
        $carrierId = (int) Configuration::get('CUSTOMCARRIER_ID_CARRIER');
        $ranges = $db->executeS('
            SELECT rp.id_range_price, rp.delimiter1, rp.delimiter2, d.price
            FROM ' . _DB_PREFIX_ . 'range_price rp
            INNER JOIN ' . _DB_PREFIX_ . 'delivery d ON rp.id_range_price = d.id_range_price
            WHERE d.id_carrier = ' . $carrierId . '
            AND d.id_zone = 1
            ORDER BY rp.delimiter1
        ');

        $formattedRanges = [];
        foreach ($ranges as $r) {
            $netto = (float)$r['price'];
            $formattedRanges[] = [
                'from' => (float)$r['delimiter1'],
                'to' => (float)$r['delimiter2'],
                'price_netto' => $netto,
                'price_brutto' => round($netto * 1.23, 2)
            ];
        }

        echo json_encode([
            'carrier_id' => $carrierId,
            'price_ranges' => $formattedRanges
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($cartId <= 0) {
        // Show recent carts with products
        $recentCarts = $db->executeS('
            SELECT c.id_cart, c.date_upd, COUNT(cp.id_product) as product_count,
                   SUM(cp.quantity) as total_quantity
            FROM ' . _DB_PREFIX_ . 'cart c
            INNER JOIN ' . _DB_PREFIX_ . 'cart_product cp ON c.id_cart = cp.id_cart
            WHERE c.date_upd > DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY c.id_cart
            HAVING product_count > 0
            ORDER BY c.date_upd DESC
            LIMIT 10
        ');

        echo json_encode([
            'info' => 'Podaj ?cart_id=X aby zobaczyć szczegóły koszyka',
            'recent_carts' => $recentCarts
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Get cart products
    $cartProducts = $db->executeS('
        SELECT cp.id_product, cp.quantity, pl.name
        FROM ' . _DB_PREFIX_ . 'cart_product cp
        INNER JOIN ' . _DB_PREFIX_ . 'product_lang pl
            ON cp.id_product = pl.id_product AND pl.id_lang = 1 AND pl.id_shop = 1
        WHERE cp.id_cart = ' . (int)$cartId
    );

    if (empty($cartProducts)) {
        echo json_encode(['error' => 'Koszyk pusty lub nie istnieje', 'cart_id' => $cartId]);
        exit;
    }

    // Get cart total value
    $cartTotal = $db->getValue('
        SELECT SUM(cp.quantity * p.price)
        FROM ' . _DB_PREFIX_ . 'cart_product cp
        INNER JOIN ' . _DB_PREFIX_ . 'product p ON cp.id_product = p.id_product
        WHERE cp.id_cart = ' . (int)$cartId
    );
    $cartTotal = (float) $cartTotal;

    // Get carrier ID from customcarrier module
    $carrierId = (int) Configuration::get('CUSTOMCARRIER_ID_CARRIER');

    // Get wizard free shipping threshold (price range where cost = 0)
    $wizardThreshold = null;
    if ($carrierId > 0) {
        $thresholdRow = $db->getRow('
            SELECT MIN(rp.delimiter1) as threshold
            FROM ' . _DB_PREFIX_ . 'range_price rp
            INNER JOIN ' . _DB_PREFIX_ . 'delivery d ON rp.id_range_price = d.id_range_price
            WHERE d.id_carrier = ' . $carrierId . '
            AND d.price = 0
            AND rp.delimiter1 > 0
        ');
        if ($thresholdRow && $thresholdRow['threshold'] > 0) {
            $wizardThreshold = (float) $thresholdRow['threshold'];
        }
    }

    $thresholdMet = ($wizardThreshold !== null && $cartTotal >= $wizardThreshold);

    $result = [
        'cart_id' => $cartId,
        'cart_total_netto' => round($cartTotal, 2),
        'cart_total_brutto' => round($cartTotal * 1.23, 2),
        'wizard_threshold' => $wizardThreshold,
        'threshold_met' => $thresholdMet,
        'carrier_id' => $carrierId,
        'products_count' => count($cartProducts),
        'products' => []
    ];

    foreach ($cartProducts as $cp) {
        $idProduct = (int) $cp['id_product'];
        $quantity = (int) $cp['quantity'];

        // Get custom carrier settings
        $settings = $db->getRow('SELECT * FROM ' . _DB_PREFIX_ . 'customcarrier_product WHERE id_product = ' . $idProduct);

        $productData = [
            'id_product' => $idProduct,
            'name' => $cp['name'],
            'quantity' => $quantity,
            'has_custom_settings' => !empty($settings),
            'settings' => $settings ? [
                'base_shipping_cost' => (float) ($settings['base_shipping_cost'] ?? 0),
                'free_shipping' => (int) ($settings['free_shipping'] ?? 0),
                'multiply_by_quantity' => (int) ($settings['multiply_by_quantity'] ?? 0),
                'separate_package' => (int) ($settings['separate_package'] ?? 0),
                'exclude_from_free_shipping' => (int) ($settings['exclude_from_free_shipping'] ?? 0),
                'apply_threshold' => (int) ($settings['apply_threshold'] ?? 0),
                'max_quantity_per_package' => (int) ($settings['max_quantity_per_package'] ?? 0),
                'max_packages' => (int) ($settings['max_packages'] ?? 0),
                'cost_above_max_packages' => (float) ($settings['cost_above_max_packages'] ?? 0),
            ] : null
        ];

        // Calculate shipping for this product
        if ($settings) {
            $baseCost = (float) ($settings['base_shipping_cost'] ?? 0);
            $maxQtyPerPackage = (int) ($settings['max_quantity_per_package'] ?? 0);
            $multiplyByQty = (int) ($settings['multiply_by_quantity'] ?? 0);
            $separatePackage = (int) ($settings['separate_package'] ?? 0);

            $calculatedCost = 0;
            $calculationMethod = '';

            if ($maxQtyPerPackage > 0) {
                $packageCount = (int) ceil($quantity / $maxQtyPerPackage);
                $calculatedCost = $baseCost * $packageCount;
                $calculationMethod = "packages: ceil($quantity / $maxQtyPerPackage) = $packageCount paczek × $baseCost zł";
            } elseif ($multiplyByQty) {
                $calculatedCost = $baseCost * $quantity;
                $calculationMethod = "multiply: $quantity × $baseCost zł";
            } else {
                $calculatedCost = $baseCost;
                $calculationMethod = "base: $baseCost zł";
            }

            $productData['calculated_cost_brutto'] = $calculatedCost;
            $productData['calculated_cost_netto'] = round($calculatedCost / 1.23, 2);
            $productData['calculation_method'] = $calculationMethod;
            $productData['aggregation'] = ($separatePackage || $multiplyByQty) ? 'SUMOWANE' : 'MAX (standardowa paczka)';

            // Check threshold behavior
            $applyThreshold = (int) ($settings['apply_threshold'] ?? 0);
            $excludeFromFree = (int) ($settings['exclude_from_free_shipping'] ?? 0);

            if ($thresholdMet) {
                if ($excludeFromFree) {
                    $productData['threshold_effect'] = 'PŁATNA (exclude_from_free_shipping blokuje)';
                } elseif ($separatePackage) {
                    $productData['threshold_effect'] = 'PŁATNA (separate_package blokuje)';
                } elseif ($applyThreshold) {
                    $productData['threshold_effect'] = 'DARMOWA (apply_threshold = TAK)';
                } else {
                    $productData['threshold_effect'] = 'PŁATNA (apply_threshold = NIE)';
                }
            } else {
                $productData['threshold_effect'] = 'N/A (próg nie osiągnięty)';
            }
        }

        $result['products'][] = $productData;
    }

    // Summarize aggregation
    $summedCosts = 0;
    $standardCosts = [];
    $hasProductsWithoutSettings = false;

    foreach ($result['products'] as $p) {
        if (!$p['has_custom_settings']) {
            $hasProductsWithoutSettings = true;
        } else {
            $settings = $p['settings'];
            if ($settings['separate_package'] || $settings['multiply_by_quantity']) {
                $summedCosts += $p['calculated_cost_brutto'];
            } else {
                $standardCosts[] = $p['calculated_cost_brutto'];
            }
        }
    }

    $maxStandard = !empty($standardCosts) ? max($standardCosts) : 0;

    $result['aggregation'] = [
        'summed_costs_brutto' => $summedCosts,
        'standard_costs_brutto' => $standardCosts,
        'max_standard_brutto' => $maxStandard,
        'has_products_without_settings' => $hasProductsWithoutSettings,
        'final_brutto' => $summedCosts + $maxStandard,
        'final_netto' => round(($summedCosts + $maxStandard) / 1.23, 2),
        'explanation' => 'Koszt = SUMA(osobne paczki) + MAX(standardowe). PrestaShop dodaje VAT do netto.'
    ];

    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        'error' => true,
        'message' => $e->getMessage()
    ], JSON_PRETTY_PRINT);
}
