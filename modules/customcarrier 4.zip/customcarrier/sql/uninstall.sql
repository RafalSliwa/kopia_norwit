-- Custom Carrier Module - Uninstallation SQL

DROP TABLE IF EXISTS `PREFIX_customcarrier_product`;
DROP TABLE IF EXISTS `PREFIX_customcarrier_zone`;
