<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ordercountdown}prestashop>ordercountdown_54f2d905f385f08dc97cf0794b2a03db'] = 'Wyświetla odliczanie czasu do złożenia zamówienia z możliwością wysyłki tego samego dnia.';
$_MODULE['<{ordercountdown}prestashop>ordercountdown_680664eb4b9da6fc6f2abab71974c626'] = 'U Ciebie w poniedziałek';
$_MODULE['<{ordercountdown}prestashop>ordercountdown_9fa3bd403138c1382367cb1bc2707dbd'] = 'U Ciebie w wtorek';
$_MODULE['<{ordercountdown}prestashop>ordercountdown_e458194f30e040fa5d2c461facf51bfb'] = 'U ciebie jutro';
$_MODULE['<{ordercountdown}prestashop>ordercountdown_3c0cf4c50304d602cd66b733313e7905'] = 'U Ciebie w środę';
$_MODULE['<{ordercountdown}prestashop>ordercountdown_7f8ae9a07980f5941d0d77e8b1309747'] = 'U Ciebie w czwartek';
$_MODULE['<{ordercountdown}prestashop>ordercountdown_e12a718715266903248a150551322ce8'] = 'U Ciebie w piątek';
$_MODULE['<{ordercountdown}prestashop>ordercountdown_d01aa533a73b9fc002ba83aae80b0e79'] = 'Czas wysyłki 2-3 dni robocze.';
$_MODULE['<{ordercountdown}prestashop>displaycountdownmobile_faeaec9eda6bc4c8cb6e1a9156a858be'] = 'Dostępność';
$_MODULE['<{ordercountdown}prestashop>displaycountdownmobile_64e39de43a876d41d177e7366411e8fa'] = 'szt. na magazynie';
$_MODULE['<{ordercountdown}prestashop>displaycountdownmobile_1f26971c6fa301196457c4e184c7516d'] = ' Wysyłka z magazynu dostawcy';
$_MODULE['<{ordercountdown}prestashop>displaycountdownmobile_72aca17331d2b5b14ad0c3f04c9b8988'] = 'Czas do wysyłki';
$_MODULE['<{ordercountdown}prestashop>displaycountdownmobile_0c4f82ac8c388cb72b1ba684f10fa098'] = 'Termin dostawy';
$_MODULE['<{ordercountdown}prestashop>displaycountdown_faeaec9eda6bc4c8cb6e1a9156a858be'] = 'Dostępność';
$_MODULE['<{ordercountdown}prestashop>displaycountdown_64e39de43a876d41d177e7366411e8fa'] = 'szt. na magazynie';
$_MODULE['<{ordercountdown}prestashop>displaycountdown_1f26971c6fa301196457c4e184c7516d'] = ' Wysyłka z magazynu dostawcy';
$_MODULE['<{ordercountdown}prestashop>displaycountdown_72aca17331d2b5b14ad0c3f04c9b8988'] = 'Czas do wysyłki';
$_MODULE['<{ordercountdown}prestashop>displaycountdown_0c4f82ac8c388cb72b1ba684f10fa098'] = 'Termin dostawy';
