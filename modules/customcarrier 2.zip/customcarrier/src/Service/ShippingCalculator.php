<?php
/**
 * Shipping Calculator Service
 *
 * Main service for calculating shipping costs based on product rules.
 */

declare(strict_types=1);

namespace CustomCarrier\Service;

use CustomCarrier\Entity\CustomCarrierProduct;
use CustomCarrier\Repository\CustomCarrierProductRepository;
use Doctrine\DBAL\Connection;

class ShippingCalculator
{
    /** @var Connection */
    private Connection $connection;

    /** @var string */
    private string $dbPrefix;

    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
        $this->dbPrefix = _DB_PREFIX_;
    }

    /**
     * Calculate total shipping cost for a cart
     *
     * @param \Cart $cart Cart object
     * @param int $idZone Zone ID (for future threshold calculations)
     * @return float Total shipping cost
     */
    public function calculateForCart(\Cart $cart, int $idZone = 0): float
    {
        $products = $cart->getProducts();

        if (empty($products)) {
            return 0.0;
        }

        // Get product IDs
        $productIds = array_map(function ($product) {
            return (int) $product['id_product'];
        }, $products);

        // Fetch all product settings at once
        $settingsMap = $this->getProductSettingsMap($productIds);

        $totalCost = 0.0;

        foreach ($products as $product) {
            $idProduct = (int) $product['id_product'];
            $quantity = (int) $product['cart_quantity'];

            $settings = $settingsMap[$idProduct] ?? null;

            $productCost = $this->calculateForProduct($settings, $quantity);
            $totalCost += $productCost;
        }

        return $totalCost;
    }

    /**
     * Calculate shipping cost for a single product
     *
     * @param CustomCarrierProduct|null $settings Product settings
     * @param int $quantity Quantity in cart
     * @return float Shipping cost for this product
     */
    public function calculateForProduct(?CustomCarrierProduct $settings, int $quantity): float
    {
        // No settings = no custom cost (use default carrier behavior)
        if ($settings === null) {
            return 0.0;
        }

        // Free shipping - unconditional
        if ($settings->isFreeShipping()) {
            return 0.0;
        }

        $baseCost = $settings->getBaseShippingCost();

        // Multiply by quantity if enabled
        if ($settings->isMultiplyByQuantity()) {
            return $baseCost * $quantity;
        }

        return $baseCost;
    }

    /**
     * Get detailed breakdown of shipping costs
     *
     * @param \Cart $cart Cart object
     * @param int $idZone Zone ID
     * @return array Breakdown of costs per product
     */
    public function getBreakdown(\Cart $cart, int $idZone = 0): array
    {
        $products = $cart->getProducts();
        $breakdown = [];

        if (empty($products)) {
            return $breakdown;
        }

        $productIds = array_map(function ($product) {
            return (int) $product['id_product'];
        }, $products);

        $settingsMap = $this->getProductSettingsMap($productIds);

        foreach ($products as $product) {
            $idProduct = (int) $product['id_product'];
            $quantity = (int) $product['cart_quantity'];
            $settings = $settingsMap[$idProduct] ?? null;

            $cost = $this->calculateForProduct($settings, $quantity);

            $breakdown[] = [
                'id_product' => $idProduct,
                'product_name' => $product['name'],
                'quantity' => $quantity,
                'free_shipping' => $settings ? $settings->isFreeShipping() : false,
                'base_cost' => $settings ? $settings->getBaseShippingCost() : 0.0,
                'multiply_by_quantity' => $settings ? $settings->isMultiplyByQuantity() : false,
                'calculated_cost' => $cost,
            ];
        }

        return $breakdown;
    }

    /**
     * Get product settings map for multiple products
     *
     * @param int[] $productIds
     * @return array<int, CustomCarrierProduct>
     */
    protected function getProductSettingsMap(array $productIds): array
    {
        if (empty($productIds)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($productIds), '?'));

        $sql = "SELECT * FROM {$this->dbPrefix}customcarrier_product
                WHERE id_product IN ({$placeholders})";

        $results = $this->connection->fetchAllAssociative($sql, $productIds);

        $map = [];
        foreach ($results as $row) {
            $entity = CustomCarrierProduct::fromArray($row);
            $map[$entity->getIdProduct()] = $entity;
        }

        return $map;
    }
}
