<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{customcarrier}prestashop>product_tab_7366b8b9d084c2939c2bc5301d05eb53'] = 'Niestandardowe ustawienia operatora';
$_MODULE['<{customcarrier}prestashop>product_tab_73fb7e9c18e352c677f249cbe53fb394'] = 'Skonfiguruj zasady dotyczące kosztów wysyłki dla tego produktu. Te ustawienia zostaną wykorzystane przez moduł Custom Carrier do obliczenia kosztów wysyłki.';
$_MODULE['<{customcarrier}prestashop>product_tab_29aa46cc3d2677c7e0f216910df600ff'] = 'Bezpłatna wysyłka';
$_MODULE['<{customcarrier}prestashop>product_tab_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Od';
$_MODULE['<{customcarrier}prestashop>product_tab_93cba07454f06a4a960172bbd6e2a435'] = 'Tak';
$_MODULE['<{customcarrier}prestashop>product_tab_f258099bbf15ffe11c7a2f5f329a484e'] = 'Jeśli opcja jest włączona, ten produkt będzie zawsze objęty bezpłatną wysyłką (najwyższy priorytet).';
$_MODULE['<{customcarrier}prestashop>product_tab_03334947eae6089b86d68756e7410312'] = 'Podstawowy koszt wysyłki';
$_MODULE['<{customcarrier}prestashop>product_tab_0e460d0edd4cfec4c2d0f2c000466b8a'] = 'Podstawowy koszt wysyłki tego produktu.';
$_MODULE['<{customcarrier}prestashop>product_tab_86069e740c36aab3dbe8f1d852640a90'] = 'Pomnóż przez ilość';
$_MODULE['<{customcarrier}prestashop>product_tab_30fccc1e3057a07ed7874011a2b2aacf'] = 'Jeśli opcja jest włączona, koszt wysyłki = koszt podstawowy × ilość.';
$_MODULE['<{customcarrier}prestashop>product_tab_0f5ebdb24911c3d558481af49718bf18'] = 'Bezpłatna wysyłka od ilości';
$_MODULE['<{customcarrier}prestashop>product_tab_3ecf2642759a04bd3616642bd56bed59'] = 'szt.';
$_MODULE['<{customcarrier}prestashop>product_tab_615d2279c9a975a6e4af7165dd21fa66'] = 'Bezpłatna wysyłka, gdy klient zamówi co najmniej określoną liczbę produktów. Aby wyłączyć tę opcję, ustaw wartość 0.';
$_MODULE['<{customcarrier}prestashop>product_tab_6e79ab43c811a1dab281a7289407c0e0'] = 'Zastosuj próg wartości koszyka';
$_MODULE['<{customcarrier}prestashop>product_tab_0fdff1e833b2fe4e78c0a976fdf2eb7a'] = 'Jeśli opcja jest włączona, wysyłka jest bezpłatna, gdy wartość koszyka przekracza próg strefy (skonfigurowany w ustawieniach modułu).';
$_MODULE['<{customcarrier}prestashop>product_tab_da9ed88c2d71a5fc367eb21a354e956c'] = 'Osobna paczka';
$_MODULE['<{customcarrier}prestashop>product_tab_504da8961d453f5d28a6acfb2104f2b2'] = 'Jeśli opcja jest włączona, produkt ten jest zawsze wysyłany osobno (np. przedmioty ponadgabarytowe). Koszt obliczany jest niezależnie.';
$_MODULE['<{customcarrier}prestashop>product_tab_ac66024fe3cf3c7104645796d2edcf45'] = 'Wyłącz z darmowej wysyłki';
$_MODULE['<{customcarrier}prestashop>product_tab_7f97d8bf974f36f38c0f04f41187ad92'] = 'Jeśli włączone, ten produkt nigdy nie otrzyma darmowej wysyłki (ignoruje wszystkie reguły darmowej wysyłki).';
