# Related Products - Changelog

## v1.1.0 (2026-02-05)

### ✨ Internacjonalizacja

- **Usunięto wszystkie hardcoded teksty** - moduł w pełni zgodny z systemem tłumaczeń PrestaShop
- Naprawiono hardcoded polskie komunikaty w `relatedproducts.php`:
  - 13+ wystąpień `"Za darmo!"` → `$this->l('Free!')`
  - `"Kurier Norwit 01"` → `$this->l('Courier Norwit 01')`
  - `"Standard delivery"` → `$this->l('Standard delivery')`
  - `"Przesyłka kurierska"` → `$this->l('Courier shipment')`
  - `"Wysyłka"` → `$this->l('Shipping')`
  - Symbol waluty `" zł"` → `Tools::displayPrice()`
- Naprawiono hardcoded komunikaty JavaScript w `relatedproducts-cart.js`:
  - 5 komunikatów błędów i etykiet
  - Wszystkie przekazane przez `Media::addJsDef()` z tłumaczeniami
  - Fallback na angielskie teksty gdy tłumaczenia niedostępne
- **Dodano 10 nowych tłumaczeń polskich** w `translations/pl.php`

### 🔧 Zmiany techniczne

- Dodano obiekt `relatedproducts_translations` w JavaScript (przekazywany przez PHP)
- Używa PrestaShop `Media::addJsDef()` do przekazywania tłumaczeń do JS
- Wszystkie komunikaty użytkownika teraz tłumaczalne przez system PrestaShop

---

## v1.0.7 (poprzednia wersja)

- Stabilna wersja z podstawowymi funkcjonalnościami
- Integracja z customcarrier module
- Wyświetlanie powiązanych produktów w modal
- Kalkulacja kosztów wysyłki
- Obsługa progów darmowej dostawy
