<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{relatedproducts}prestashop>relatedproducts_b11466489be6a38386ea5e3795cff1ba'] = 'Powiązane produkty w szablonie modal.';
$_MODULE['<{relatedproducts}prestashop>relatedproducts_f86274be9624bb140157db11ad6c37d7'] = 'Wyświetla zaawansowany moduł koszyka z informacjami o dostawie i powiązanych produktach.';
$_MODULE['<{relatedproducts}prestashop>displayproductmodal_14a3817d0d3642f66bca566f9f5bd242'] = 'Przydatne akcesoria';
$_MODULE['<{relatedproducts}prestashop>displayproductmodal_652da9495cd8e2c544b6e853f105a33a'] = 'Produkty z tej samej kategorii';
$_MODULE['<{relatedproducts}prestashop>displayproductmodal_887ee91702c962a70b87cbef07bbcaec'] = 'netto';
$_MODULE['<{relatedproducts}prestashop>displayproductmodal_eb5d1fb5569da6ef26ecc8d57d4d2074'] = 'Zapytaj o cene';
$_MODULE['<{relatedproducts}prestashop>displayproductmodal_2d0f6b8300be19cf35e89e66f0677f95'] = 'Dodaj do koszyka';
$_MODULE['<{relatedproducts}prestashop>modal_e21326cc671ce231c0ba9599707dcc2e'] = 'U ciebie jutro';
$_MODULE['<{relatedproducts}prestashop>modal_2a9b8fdb9dbc0e3f7a0a686036831c8d'] = 'At your place tomorrow';
$_MODULE['<{relatedproducts}prestashop>modal_4a60c5a45f0f674dcef5f52b1c4b62d5'] = 'U ciebie w poniedziałek';
$_MODULE['<{relatedproducts}prestashop>modal_5a4e3797b0b4cb16cb6c10c60b474455'] = 'At your place on Monday';

// Shipping related translations (modal.tpl)
$_MODULE['<{relatedproducts}prestashop>modal_dostawa_od'] = 'Dostawa od:';
$_MODULE['<{relatedproducts}prestashop>modal_dostawa'] = 'Dostawa:';
$_MODULE['<{relatedproducts}prestashop>modal_za_darmo'] = 'Za darmo!';
$_MODULE['<{relatedproducts}prestashop>modal_brakuje_do_darmowej'] = 'Do darmowej dostawy brakuje Ci';
$_MODULE['<{relatedproducts}prestashop>modal_brak_darmowej_dostawy'] = 'Darmowa dostawa nie obowiązuje dla tego produktu.';

// New translations for internationalization (v1.1.0)
// PHP translations
$_MODULE['<{relatedproducts}prestashop>relatedproducts_5b268c4a82f0a351d8c3e65dcf0026cd'] = 'Za darmo!'; // Free!
$_MODULE['<{relatedproducts}prestashop>relatedproducts_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Dostawa standardowa'; // Standard delivery
$_MODULE['<{relatedproducts}prestashop>relatedproducts_8c489d0946f66d17d73f26c0d63bf531'] = 'Kurier Norwit 01'; // Courier Norwit 01
$_MODULE['<{relatedproducts}prestashop>relatedproducts_5af7e72e39c643ae23c2fa2c7ac20cbb'] = 'Przesyłka kurierska'; // Courier shipment
$_MODULE['<{relatedproducts}prestashop>relatedproducts_4fbddd4c46473e5bc92e3296b3b86e8f'] = 'Wysyłka'; // Shipping

// JavaScript translations
$_MODULE['<{relatedproducts}prestashop>relatedproducts_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Żądanie koszyka zakończyło się błędem'; // Cart request ended with error
$_MODULE['<{relatedproducts}prestashop>relatedproducts_52f9ec21735243ad9947b5c1ee5a1cb1'] = 'Wystąpił błąd podczas dodawania produktu do koszyka'; // An error occurred while adding the product to cart
$_MODULE['<{relatedproducts}prestashop>relatedproducts_aae4c1b6b5c0e8f76f620d28b6d3a4d9'] = 'Produkt został pomyślnie dodany do koszyka'; // Product was successfully added to cart
$_MODULE['<{relatedproducts}prestashop>relatedproducts_5788e70f989ba733c8a42c6b6b34f52e'] = 'Limit przekroczony'; // Limit exceeded
$_MODULE['<{relatedproducts}prestashop>relatedproducts_e3a3f8f2d1618e24b38cd1c73d0a5ed1'] = 'Dostawa od:'; // Delivery from:
