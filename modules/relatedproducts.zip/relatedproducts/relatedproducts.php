<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

class RelatedProducts extends Module implements WidgetInterface
{
    public function __construct()
    {
        $this->name = 'relatedproducts';
        $this->version = '1.0.5';
        $this->author = 'Norwit';
        $this->need_instance = 0;

        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Related products in modal template.');
        $this->description = $this->l('Displays advanced cart modal with delivery info and related products.');
    }

    public function install()
    {
        return parent::install()
            && $this->registerHook('displayProductModal')
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayCartModalContent');
    }


    /**
     * Adds CSS and AJAX to page
     */
    public function hookDisplayHeader()
    {
        // Add free shipping threshold to Smarty global variables
        if (isset($this->context->cart) && $this->context->cart->id) {
            $products = $this->context->cart->getProducts();
            
            // Check number of products in cart
            $totalQuantity = $this->context->cart->nbProducts(); // total quantity
            $uniqueCount = count($products); // unique items
            
            // Get shipping costs
            $shippingCost = $this->context->cart->getTotalShippingCost();
            $shippingCostWithTax = $this->context->cart->getTotalShippingCost(null, true);
            $shippingCostWithoutTax = $this->context->cart->getTotalShippingCost(null, false);
            
            if (!empty($products)) {
                $lastProduct = end($products);
                $threshold = $this->getFreeShippingThreshold($lastProduct['id_product']);
                $this->context->smarty->assign([
                    'free_shipping_threshold' => $threshold,
                    'modal_product_id' => $lastProduct['id_product']
                ]);
            }
        }

        $this->context->controller->registerStylesheet(
            'relatedproducts-modal',
            'modules/'.$this->name.'/views/css/relatedproducts-modal.css',
            [
                'media' => 'all',
                'priority' => 50
            ]
        );

        $this->context->controller->registerJavascript(
            'module-relatedproducts-js',
            'modules/' . $this->name . '/views/js/relatedproducts-cart.js',
            ['position' => 'bottom', 'priority' => 150]
        );
        $this->context->controller->registerJavascript(
            'module-relatedproducts-carousel-js',
            'modules/' . $this->name . '/views/js/relatedproducts.js',
            ['position' => 'bottom', 'priority' => 150]
        );
    }

    public function uninstall()
    {
        return parent::uninstall();
    }



    /**
     * Called by hook engine - for related products
     */
    public function renderWidget($hookName, array $configuration)
    {
        $variables = $this->getWidgetVariables($hookName, $configuration);
        
        // Add free shipping threshold to variables
        if (isset($configuration['id_product'])) {
            $variables['free_shipping_threshold'] = $this->getFreeShippingThreshold($configuration['id_product']);
        }
        
        $this->smarty->assign($variables);
        return $this->fetch('module:relatedproducts/views/templates/hook/displayProductModal.tpl');
    }

    /**
     * Gets free shipping threshold for product (for use in template)
     */
    public static function getProductFreeShippingThreshold($id_product)
    {
        $module = new self();
        return $module->getFreeShippingThreshold($id_product);
    }

    /**
     * Returns data for view (e.g. list of related products)
     */
    public function getWidgetVariables($hookName, array $configuration)
    {
        if (!isset($configuration['id_product'])) {
            return [];
        }

        $id_product = (int)$configuration['id_product'];
        $id_lang = (int)$this->context->language->id;

        $product = new Product($id_product, false, $id_lang);
        if (!Validate::isLoadedObject($product)) {
            return [
                'related_products' => [],
                'recommendation_type' => 'accessories',
            ];
        }
        $accessories = $product->getAccessories($id_lang);
        $recommendationType = 'accessories'; // Typ rekomendacji

        // If no accessories, fetch products from the same category
        if (empty($accessories)) {
            $accessories = $this->getProductsFromSameCategory($id_product, $id_lang);
            $recommendationType = 'category';
        }

        // For category products, use different data fetching method
        if ($recommendationType === 'category') {
            $products = $this->formatCategoryProducts($accessories, $id_lang);
        } else {
            $products = Product::getProductsProperties($id_lang, $accessories);
            
            // Format prices for accessories in the same way as for category products
            foreach ($products as &$related) {
                // Format prices
                if (isset($related['price'])) {
                    $related['price'] = Tools::displayPrice($related['price']);
                }
                if (isset($related['price_tax_exc'])) {
                    $related['price_tax_exc'] = Tools::displayPrice($related['price_tax_exc']);
                }
                
                $imageId = null;

                // Prefer 'cover_image_id' if set
                if (!empty($related['cover_image_id'])) {
                    $imageId = (int) $related['cover_image_id'];
                } elseif (!empty($related['id_image'])) {
                    $imageId = (int) explode('-', $related['id_image'])[0];
                }

                if ($imageId) {
                    $related['image_url'] = $this->context->link->getImageLink(
                        $related['link_rewrite'],
                        $imageId,
                        'home_default'
                    );
                } else {
                    $related['image_url'] = $this->context->link->getImageLink(
                        'default',
                        null,
                        'home_default'
                    );
                }
            }
        }
        return [
            'related_products' => $products,
            'recommendation_type' => $recommendationType,
        ];
    }

    /**
     * Fetches products from the same category as given product
     */
    private function getProductsFromSameCategory($id_product, $id_lang, $limit = 8)
    {
        $product = new Product($id_product, false, $id_lang);
        $categories = $product->getCategories();
        
        if (empty($categories)) {
            return [];
        }

        // Select main category (first on list)
        $main_category = $categories[0];
        
        // Get products from this category (excluding current product)
        // Using standard PrestaShop function with additional conditions
        $sql = new DbQuery();
    $context = Context::getContext();
    $idShop = (int) $context->shop->id;
    $idShopGroup = (int) $context->shop->id_shop_group;

    $sql->select('p.id_product, pl.name, pl.link_rewrite');
        $sql->from('product', 'p');
        $sql->innerJoin('category_product', 'cp', 'p.id_product = cp.id_product');
    $sql->innerJoin('product_shop', 'pshop', 'p.id_product = pshop.id_product AND pshop.id_shop = ' . $idShop);
    $sql->innerJoin('product_lang', 'pl', 'p.id_product = pl.id_product AND pl.id_lang = ' . (int)$id_lang . ' AND pl.id_shop = ' . $idShop);
    $sql->leftJoin('stock_available', 'stock', 'p.id_product = stock.id_product AND stock.id_product_attribute = 0 AND (stock.id_shop = ' . $idShop . ' OR stock.id_shop = 0) AND (stock.id_shop_group = ' . $idShopGroup . ' OR stock.id_shop_group = 0)');
        $sql->where('cp.id_category = ' . (int)$main_category);
        $sql->where('p.id_product != ' . (int)$id_product);
        $sql->where('p.active = 1');
    $sql->where('pshop.active = 1');
    $sql->where('pl.name IS NOT NULL AND pl.name != ""');
    $sql->orderBy('stock.quantity DESC, RAND()');
        $sql->limit($limit);

        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        
        if (!$results) {
            return [];
        }

        // Return products in format compatible with getAccessories()
        $categoryProducts = [];
        foreach ($results as $row) {
            $categoryProducts[] = [
                'id_product' => (int)$row['id_product'],
                'name' => $row['name'],
                'link_rewrite' => $row['link_rewrite']
            ];
        }
        
        return $categoryProducts;
    }

    /**
     * Formats category product data for display
     */
    private function formatCategoryProducts($categoryProducts, $id_lang)
    {
        $formattedProducts = [];
        
        foreach ($categoryProducts as $productData) {
            $id_product = (int)$productData['id_product'];
            $product = new Product($id_product, true, $id_lang);
            
            if (!Validate::isLoadedObject($product)) {
                continue; // Skip invalid products
            }

            $link = $this->context->link->getProductLink($product);
            $price = Product::getPriceStatic($id_product, true, null, 6, null, false, true, 1, true);
            
            // Get main product image
            $cover = Product::getCover($id_product);
            $imageUrl = '';
            if ($cover) {
                $imageUrl = $this->context->link->getImageLink(
                    $product->link_rewrite,
                    $cover['id_image'],
                    'home_default'
                );
            } else {
                $imageUrl = $this->context->link->getImageLink(
                    'default',
                    null,
                    'home_default'
                );
            }

            $formattedProducts[] = [
                'id_product' => $id_product,
                'name' => $product->name,
                'link' => $link,
                'link_rewrite' => $product->link_rewrite,
                'price' => Tools::displayPrice($price),
                'price_tax_exc' => Tools::displayPrice(Product::getPriceStatic($id_product, false)),
                'image_url' => $imageUrl,
                'cover' => $cover
            ];
        }
        
        return $formattedProducts;
    }

    /**
     * Gets lowest carrier price for given product
     */
    public function getLowestShippingPrice($id_product)
    {
        $context = Context::getContext();
        $product = new Product($id_product, false, $context->language->id);
        
        if (!Validate::isLoadedObject($product)) {
            return [
                'price' => 2.46,
                'formatted_price' => Tools::displayPrice(2.46),
                'carrier' => ['name' => 'Standard delivery']
            ];
        }

        // Get ADDITIONAL shipping cost from product
        $additionalShippingCost = (float)$product->additional_shipping_cost;
        
        // Get product price for price ranges
        $productPrice = Product::getPriceStatic($id_product, true);
        $db = Db::getInstance();
        
        // Check if product has assigned specific carriers
        $productWeight = (float)$product->weight;
        
        $carriersQuery = '
            SELECT c.id_carrier, c.id_reference, c.name, c.active,
                   COALESCE(rw.id_range_weight, rp.id_range_price) AS range_id,
                   CASE
                       WHEN rw.id_range_weight IS NOT NULL THEN "weight"
                       WHEN rp.id_range_price IS NOT NULL THEN "price"
                       ELSE "unknown"
                   END AS range_type,
                   COALESCE(rw.delimiter1, rp.delimiter1) AS range_from,
                   COALESCE(rw.delimiter2, rp.delimiter2) AS range_to,
                   d.price AS delivery_price,
                   z.name AS zone_name
            FROM '._DB_PREFIX_.'carrier c
            INNER JOIN '._DB_PREFIX_.'product_carrier pc 
                ON pc.id_carrier_reference = c.id_reference
            INNER JOIN '._DB_PREFIX_.'delivery d 
                ON d.id_carrier = c.id_carrier
            LEFT JOIN '._DB_PREFIX_.'range_weight rw 
                ON rw.id_range_weight = d.id_range_weight
            LEFT JOIN '._DB_PREFIX_.'range_price rp 
                ON rp.id_range_price = d.id_range_price
            LEFT JOIN '._DB_PREFIX_.'zone z 
                ON z.id_zone = d.id_zone
            WHERE pc.id_product = '.(int)$id_product.'
              AND c.active = 1
              AND c.deleted = 0
              AND d.id_zone = 1
              AND (
                  (rw.id_range_weight IS NOT NULL AND '.(float)$productWeight.' >= rw.delimiter1 AND '.(float)$productWeight.' < rw.delimiter2) OR
                  (rp.id_range_price IS NOT NULL AND '.(float)$productPrice.' >= rp.delimiter1 AND '.(float)$productPrice.' < rp.delimiter2) OR
                  (rw.id_range_weight IS NULL AND rp.id_range_price IS NULL)
              )
            ORDER BY c.name, range_type, range_from
        ';

        $assignedCarriers = $db->executeS($carriersQuery);

        // If product has no assigned carriers, use all available
        if (empty($assignedCarriers)) {
            $carriersQuery = '
                SELECT c.id_carrier, c.id_reference, c.name, c.active,
                       COALESCE(rw.id_range_weight, rp.id_range_price) AS range_id,
                       CASE
                           WHEN rw.id_range_weight IS NOT NULL THEN "weight"
                           WHEN rp.id_range_price IS NOT NULL THEN "price"
                           ELSE "unknown"
                       END AS range_type,
                       COALESCE(rw.delimiter1, rp.delimiter1) AS range_from,
                       COALESCE(rw.delimiter2, rp.delimiter2) AS range_to,
                       d.price AS delivery_price,
                       z.name AS zone_name
                FROM '._DB_PREFIX_.'carrier c
                INNER JOIN '._DB_PREFIX_.'delivery d 
                    ON d.id_carrier = c.id_carrier
                LEFT JOIN '._DB_PREFIX_.'range_weight rw 
                    ON rw.id_range_weight = d.id_range_weight
                LEFT JOIN '._DB_PREFIX_.'range_price rp 
                    ON rp.id_range_price = d.id_range_price
                LEFT JOIN '._DB_PREFIX_.'zone z 
                    ON z.id_zone = d.id_zone
                WHERE c.active = 1 
                  AND c.deleted = 0
                  AND d.id_zone = 1
                  AND (
                      (rw.id_range_weight IS NOT NULL AND '.(float)$productWeight.' >= rw.delimiter1 AND '.(float)$productWeight.' < rw.delimiter2) OR
                      (rp.id_range_price IS NOT NULL AND '.(float)$productPrice.' >= rp.delimiter1 AND '.(float)$productPrice.' < rp.delimiter2) OR
                      (rw.id_range_weight IS NULL AND rp.id_range_price IS NULL)
                  )
                ORDER BY c.name, range_type, range_from
            ';
            $assignedCarriers = $db->executeS($carriersQuery);
        }
        
        $debugInfo = [];
        $lowestPrice = null;
        $lowestCarrier = null;

        foreach ($assignedCarriers as $carrier) {
            try {
                // Skip in-store pickup options - we only want carriers
                $isPickup = (
                    stripos($carrier['name'], 'sklep') !== false ||
                    stripos($carrier['name'], 'pickup') !== false ||
                    stripos($carrier['name'], 'odbiór') !== false ||
                    stripos($carrier['name'], 'magazyn') !== false ||
                    stripos($carrier['name'], 'self') !== false
                );

                if ($isPickup) {
                    // Skip pickup options - looking only for carriers
                    $debugInfo[] = [
                        'carrier_name' => $carrier['name'],
                        'carrier_id' => $carrier['id_carrier'],
                        'skipped_reason' => 'pickup_option'
                    ];
                    continue;
                }

                // Use price directly from query
                $shippingCost = (float)$carrier['delivery_price'];
                $debugQuery = [
                    'product_price' => $productPrice,
                    'product_weight' => $productWeight,
                    'range_type' => $carrier['range_type'],
                    'range_from_to' => $carrier['range_from'] . ' - ' . $carrier['range_to'],
                    'delivery_price' => $carrier['delivery_price'],
                    'zone' => $carrier['zone_name'],
                    'used_method' => 'unified_range_query'
                ];
                
                // Check if we have price from query
                if ($shippingCost > 0) {
                    $delivery = $shippingCost;
                    $debugQuery['used_method'] = 'range_price_query';
                } else {
                    // Fallback: try to get price without considering range
                    try {
                        $fallbackPrice = $db->getValue('
                            SELECT MIN(d.price)
                            FROM '._DB_PREFIX_.'delivery d
                            WHERE d.id_carrier = '.(int)$carrier['id_carrier'].'
                            AND d.id_zone = 1
                            AND d.price > 0
                        ');
                        
                        if ($fallbackPrice && $fallbackPrice > 0) {
                            $delivery = (float)$fallbackPrice;
                            $debugQuery['used_method'] = 'fallback_min_price';
                            $debugQuery['fallback_price'] = $fallbackPrice;
                        } else {
                            // If still no data, use default value
                            $delivery = 2.46;
                            $debugQuery['used_method'] = 'absolute_fallback';
                        }
                    } catch (Exception $e) {
                        $delivery = 2.46;
                        $debugQuery['used_method'] = 'error_fallback';
                        $debugQuery['fallback_error'] = $e->getMessage();
                    }
                }
                
                $debugQuery['delivery_final'] = $delivery;
                
                // Using already calculated price
                $shippingCost = (float)$delivery;

                // Zapisz info do debugowania (opcjonalne)
                $debugInfo[] = [
                    'carrier_name' => $carrier['name'],
                    'carrier_id' => $carrier['id_carrier'],
                    'price' => $shippingCost,
                    'additional_shipping_cost' => $additionalShippingCost,
                    'product_weight' => $productWeight ?? 0,
                    'debug_queries' => $debugQuery
                ];

                // Update lowest price
                if ($lowestPrice === null || $shippingCost < $lowestPrice) {
                    $lowestPrice = $shippingCost;
                    $lowestCarrier = $carrier;
                }

                } catch (Exception $e) {
                $debugInfo[] = [
                    'carrier_name' => $carrier['name'],
                    'carrier_id' => $carrier['id_carrier'],
                    'error' => $e->getMessage(),
                    'line' => $e->getLine()
                ];
                continue;
            }
        }

        // Fallback if no carriers found
        if ($lowestPrice === null) {
            $lowestPrice = 2.46;
            $lowestCarrier = ['name' => 'Standard delivery'];
        }

        // Check if heavy products (>20kg) should use pallet carrier
        $productWeight = (float)$product->weight;
        if ($productWeight > 20) {
            // Find pallet carrier
            foreach ($debugInfo as $carrierInfo) {
                if (stripos($carrierInfo['carrier_name'], 'paletowa') !== false && isset($carrierInfo['price'])) {
                    $lowestPrice = $carrierInfo['price'];
                    $lowestCarrier = ['name' => $carrierInfo['carrier_name']];
                    break;
                }
            }
        }

        // Add 23% VAT to carrier price
        $vatRate = 1.23; // 23% VAT
        $priceWithVat = $lowestPrice * $vatRate;
        
        // ADD additional shipping costs (already with VAT in database)
        $additionalShippingCostWithVat = $additionalShippingCost * $vatRate;
        $finalPrice = $priceWithVat + $additionalShippingCostWithVat;

        return [
            'price' => $finalPrice,
            'price_without_vat' => $lowestPrice + $additionalShippingCost,
            'carrier_price_with_vat' => $priceWithVat,
            'additional_shipping_cost' => $additionalShippingCostWithVat,
            'formatted_price' => Tools::displayPrice($finalPrice),
            'carrier' => $lowestCarrier,
            'debug_carriers' => $debugInfo,
            'product_id' => $id_product,
            'vat_applied' => true,
            'product_weight' => $productWeight
        ];
    }

    /**
     * Gets free shipping threshold from price ranges
     */
    public function getFreeShippingThreshold($id_product = null)
    {
        $db = Db::getInstance();
        
        // Query searching for lowest threshold where delivery = 0 (free)
        $query = '
            SELECT MIN(COALESCE(rw.delimiter1, rp.delimiter1)) AS free_threshold
            FROM '._DB_PREFIX_.'delivery d
            INNER JOIN '._DB_PREFIX_.'carrier c ON d.id_carrier = c.id_carrier
            LEFT JOIN '._DB_PREFIX_.'range_weight rw ON rw.id_range_weight = d.id_range_weight
            LEFT JOIN '._DB_PREFIX_.'range_price rp ON rp.id_range_price = d.id_range_price
            WHERE c.active = 1 
              AND c.deleted = 0
              AND d.id_zone = 1
              AND d.price = 0
              AND (rw.delimiter1 > 0 OR rp.delimiter1 > 0)
        ';
        
        // If specific product provided, check its assigned carriers
        if ($id_product) {
            $productCarriersQuery = '
                SELECT MIN(COALESCE(rw.delimiter1, rp.delimiter1)) AS free_threshold,
                       c.name as carrier_name,
                       COALESCE(rw.delimiter1, rp.delimiter1) as threshold_value
                FROM '._DB_PREFIX_.'delivery d
                INNER JOIN '._DB_PREFIX_.'carrier c ON d.id_carrier = c.id_carrier
                INNER JOIN '._DB_PREFIX_.'product_carrier pc ON pc.id_carrier_reference = c.id_reference
                LEFT JOIN '._DB_PREFIX_.'range_weight rw ON rw.id_range_weight = d.id_range_weight
                LEFT JOIN '._DB_PREFIX_.'range_price rp ON rp.id_range_price = d.id_range_price
                WHERE pc.id_product = '.(int)$id_product.'
                  AND c.active = 1 
                  AND c.deleted = 0
                  AND d.id_zone = 1
                  AND d.price = 0
                  AND (rw.delimiter1 > 0 OR rp.delimiter1 > 0)
            ';
            
            $productThreshold = $db->getValue($productCarriersQuery);
            
            $allThresholdsQuery = '
                SELECT c.name as carrier_name,
                       COALESCE(rw.delimiter1, rp.delimiter1) as threshold_value,
                       d.price as delivery_price,
                       CASE WHEN rw.delimiter1 IS NOT NULL THEN "weight" ELSE "price" END as range_type
                FROM '._DB_PREFIX_.'delivery d
                INNER JOIN '._DB_PREFIX_.'carrier c ON d.id_carrier = c.id_carrier
                INNER JOIN '._DB_PREFIX_.'product_carrier pc ON pc.id_carrier_reference = c.id_reference
                LEFT JOIN '._DB_PREFIX_.'range_weight rw ON rw.id_range_weight = d.id_range_weight
                LEFT JOIN '._DB_PREFIX_.'range_price rp ON rp.id_range_price = d.id_range_price
                WHERE pc.id_product = '.(int)$id_product.'
                  AND c.active = 1 
                  AND c.deleted = 0
                  AND d.id_zone = 1
                  AND d.price = 0
            ';
            
            $allThresholds = $db->executeS($allThresholdsQuery);
            
            if ($productThreshold && $productThreshold > 0) {
                return (float)$productThreshold;
            }
        }
        
        $threshold = $db->getValue($query);
        // If no threshold found in delivery table, use standard PrestaShop setting
        if (!$threshold || $threshold <= 0) {
            // Use standard PrestaShop setting for free shipping
            $prestashop_free_shipping = Configuration::get('PS_SHIPPING_FREE_PRICE');
            if ($prestashop_free_shipping && $prestashop_free_shipping > 0) {
                return (float)$prestashop_free_shipping;
            }
            
            // If no configuration in PrestaShop, return message in log
            return 0.0; // Return 0 - force configuration in PrestaShop
        }
        return (float)$threshold;
    }

    /**
     * AJAX endpoint for getting carrier information
     */
    public function getShippingInfo($id_product)
    {
        header('Content-Type: application/json');
        
        if ($this->context->cart && $this->context->cart->id) {
            $selectedCarrier = $this->context->cart->id_carrier;
            
            // If carrier is selected, use getTotalShippingCost directly
            if ($selectedCarrier > 0) {
                $totalWithVat = $this->context->cart->getTotalShippingCost(null, true);
                
                // Check if cart has products with additional_shipping_cost
                $cartHasAdditionalCosts = false;
                $cartProducts = $this->context->cart->getProducts();
                foreach ($cartProducts as $cartProduct) {
                    $addCost = isset($cartProduct['additional_shipping_cost']) ? (float)$cartProduct['additional_shipping_cost'] : 0;
                    if ($addCost > 0) {
                        $cartHasAdditionalCosts = true;
                        break;
                    }
                }
                
                // Check if it's REAL free shipping (cart exceeded threshold AND no additional_shipping_cost)
                // or just carrier with 0 PLN price in database
                $cartTotal = $this->context->cart->getOrderTotal(true, Cart::ONLY_PRODUCTS);
                $freeShippingThreshold = $this->getFreeShippingThreshold($id_product);
                
                $isTrulyFree = ($totalWithVat == 0 && $cartTotal >= $freeShippingThreshold && !$cartHasAdditionalCosts);
                
                // If carrier returns 0 but it's not truly free shipping,
                // use carrier simulation to find actual price
                if ($totalWithVat == 0 && !$isTrulyFree) {
                    // Go to simulation below
                } else {
                    // Return result
                    echo json_encode([
                        'success' => true,
                        'lowest_price' => $totalWithVat,
                        'formatted_price' => $isTrulyFree ? 'Za darmo!' : Tools::displayPrice($totalWithVat),
                        'carrier_name' => 'Wysyłka',
                        'calculation_method' => 'selected_carrier',
                        'is_free_shipping' => $isTrulyFree,
                        'product_id' => $id_product,
                        'free_shipping_threshold' => $freeShippingThreshold,
                        'cart_has_additional_costs' => $cartHasAdditionalCosts
                    ]);
                    exit;
                }
            }
            
            // Carrier NOT selected - simulate all carriers
            try {
                $carriers = $this->context->cart->simulateCarriersOutput(null, true);
                
                $lowestPrice = null;
                $lowestCarrierName = '';
                
                foreach ($carriers as $carrier) {
                    // simulateCarriersOutput can return different keys depending on PrestaShop version
                    $carrierPrice = 0;
                    
                    if (isset($carrier['price_with_tax'])) {
                        $carrierPrice = (float)$carrier['price_with_tax'];
                    } elseif (isset($carrier['total_price_with_tax'])) {
                        $carrierPrice = (float)$carrier['total_price_with_tax'];
                    } elseif (isset($carrier['price'])) {
                        $carrierPrice = (float)$carrier['price'];
                    }
                    
                    // Skip personal pickup options
                    $isPickup = (
                        stripos($carrier['name'], 'sklep') !== false ||
                        stripos($carrier['name'], 'pickup') !== false ||
                        stripos($carrier['name'], 'odbiór') !== false ||
                        stripos($carrier['name'], 'magazyn') !== false ||
                        stripos($carrier['name'], 'self') !== false
                    );
                    
                    if ($isPickup) {
                        continue;
                    }
                    
                    // If carrier has price 0, check if it's truly free shipping
                    if ($carrierPrice == 0) {
                        // Check free shipping threshold
                        if (!isset($cartTotal)) {
                            $cartTotal = $this->context->cart->getOrderTotal(true, Cart::ONLY_PRODUCTS);
                        }
                        if (!isset($freeShippingThreshold)) {
                            $freeShippingThreshold = $this->getFreeShippingThreshold($id_product);
                        }
                        
                        // Check if cart has products with additional_shipping_cost
                        if (!isset($cartHasAdditionalCosts)) {
                            $cartHasAdditionalCosts = false;
                            $cartProducts = $this->context->cart->getProducts();
                            foreach ($cartProducts as $cartProduct) {
                                $addCost = isset($cartProduct['additional_shipping_cost']) ? (float)$cartProduct['additional_shipping_cost'] : 0;
                                if ($addCost > 0) {
                                    $cartHasAdditionalCosts = true;
                                    break;
                                }
                            }
                        }
                        
                        if ($cartTotal >= $freeShippingThreshold && !$cartHasAdditionalCosts) {
                            // Prawdziwa darmowa dostawa!
                            $lowestPrice = 0;
                            $lowestCarrierName = $carrier['name'];
                            break;
                        } else {
                            // Carrier with price 0 but cart didn't reach threshold OR has additional_shipping_cost - skip it
                            $reason = $cartTotal < $freeShippingThreshold ? 'cart below threshold' : 'cart has additional shipping costs';
                            continue;
                        }
                    }
                    
                    if ($lowestPrice === null || $carrierPrice < $lowestPrice) {
                        $lowestPrice = $carrierPrice;
                        $lowestCarrierName = $carrier['name'];
                    }
                }
                
                if ($lowestPrice !== null) {
                    // Check if cart has products with additional_shipping_cost
                    $cartHasAdditionalCosts = false;
                    $cartProducts = $this->context->cart->getProducts();
                    foreach ($cartProducts as $cartProduct) {
                        $addCost = isset($cartProduct['additional_shipping_cost']) ? (float)$cartProduct['additional_shipping_cost'] : 0;
                        if ($addCost > 0) {
                            $cartHasAdditionalCosts = true;
                            break;
                        }
                    }
                    
                    // Check if it's truly free shipping
                    if (!isset($cartTotal)) {
                        $cartTotal = $this->context->cart->getOrderTotal(true, Cart::ONLY_PRODUCTS);
                    }
                    if (!isset($freeShippingThreshold)) {
                        $freeShippingThreshold = $this->getFreeShippingThreshold($id_product);
                    }
                    
                    // Free shipping only when: price = 0, cart >= threshold AND NO products with additional_shipping_cost
                    $isTrulyFree = ($lowestPrice == 0 && $cartTotal >= $freeShippingThreshold && !$cartHasAdditionalCosts);
                    
                    echo json_encode([
                        'success' => true,
                        'lowest_price' => $lowestPrice,
                        'formatted_price' => $isTrulyFree ? 'Za darmo!' : Tools::displayPrice($lowestPrice),
                        'carrier_name' => $lowestCarrierName,
                        'calculation_method' => 'simulated_carriers',
                        'is_free_shipping' => $isTrulyFree,
                        'product_id' => $id_product,
                        'free_shipping_threshold' => $freeShippingThreshold,
                        'cart_has_additional_costs' => $cartHasAdditionalCosts
                    ]);
                    exit;
                } else {
                    // No carrier (besides pickup) - check if cart has products with additional_shipping_cost
                    if (!isset($cartHasAdditionalCosts)) {
                        $cartHasAdditionalCosts = false;
                        $cartProducts = $this->context->cart->getProducts();
                        foreach ($cartProducts as $cartProduct) {
                            $addCost = isset($cartProduct['additional_shipping_cost']) ? (float)$cartProduct['additional_shipping_cost'] : 0;
                            if ($addCost > 0) {
                                $cartHasAdditionalCosts = true;
                                break;
                            }
                        }
                    }
                    
                    // If there are products with additional_shipping_cost and no common carrier
                    // Return special message
                    if ($cartHasAdditionalCosts) {
                        echo json_encode([
                            'success' => true,
                            'lowest_price' => 0,
                            'formatted_price' => 'Koszt wysyłki do ustalenia<br>z naszym biurem obsługi klienta',
                            'carrier_name' => 'Specjalna wysyłka',
                            'calculation_method' => 'no_common_carrier',
                            'is_free_shipping' => false,
                            'product_id' => $id_product,
                            'free_shipping_threshold' => $this->getFreeShippingThreshold($id_product),
                            'cart_has_additional_costs' => true
                        ]);
                        exit;
                    }
                }
            } catch (Exception $e) {
            }
        }
        
        // Check if cart has products with additional_shipping_cost (for fallback)
        if (!isset($cartHasAdditionalCosts)) {
            $cartHasAdditionalCosts = false;
            $cartProducts = $this->context->cart->getProducts();
            foreach ($cartProducts as $cartProduct) {
                $addCost = isset($cartProduct['additional_shipping_cost']) ? (float)$cartProduct['additional_shipping_cost'] : 0;
                if ($addCost > 0) {
                    $cartHasAdditionalCosts = true;
                    break;
                }
            }
        }
        
        // Fallback: if cart doesn't have calculated shipping yet, use old method for single product
        $shippingInfo = $this->getLowestShippingPrice($id_product);
        
        if ($shippingInfo && $shippingInfo['price'] !== null) {
            echo json_encode([
                'success' => true,
                'lowest_price' => $shippingInfo['price'],
                'formatted_price' => $shippingInfo['formatted_price'],
                'carrier_name' => $shippingInfo['carrier']['name'] ?? 'Unknown',
                'debug_carriers' => $shippingInfo['debug_carriers'] ?? [],
                'product_id' => $shippingInfo['product_id'] ?? null,
                'free_shipping_threshold' => $this->getFreeShippingThreshold($id_product),
                'cart_has_additional_costs' => $cartHasAdditionalCosts
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'No shipping options available'
            ]);
        }
        exit;
    }

    /**
     * Get lowest carrier cost (without additional_shipping_cost)
     */
    private function getLowestCarrierCost()
    {
        $db = Db::getInstance();
        
        // Get cheapest active carrier for zone 1
        $query = '
            SELECT MIN(d.price) AS lowest_price
            FROM '._DB_PREFIX_.'carrier c
            INNER JOIN '._DB_PREFIX_.'delivery d ON d.id_carrier = c.id_carrier
            WHERE c.active = 1
              AND c.deleted = 0
              AND d.id_zone = 1
              AND d.price > 0
        ';
        
        $lowestPrice = $db->getValue($query);
        
        return $lowestPrice ? (float)$lowestPrice : 25.0; // Fallback 25 PLN
    }

    /**
     * AJAX endpoint do pobierania progu darmowej dostawy
     */
    public function getFreeShippingThresholdInfo($id_product = null)
    {
        header('Content-Type: application/json');
        
        $threshold = $this->getFreeShippingThreshold($id_product);
        
        echo json_encode([
            'success' => true,
            'threshold' => $threshold, // Added for JS compatibility
            'free_shipping_threshold' => $threshold,
            'formatted_threshold' => number_format($threshold, 0, ',', ' '),
            'product_id' => $id_product
        ]);
        exit;
    }

    /**
     * Hook called in cart modal
     */
    public function hookDisplayCartModalContent($params)
    {
        if (isset($params['product']['id_product'])) {
            $id_product = (int)$params['product']['id_product'];
            $freeShippingThreshold = $this->getFreeShippingThreshold($id_product);
            
            $this->context->smarty->assign([
                'free_shipping_threshold' => $freeShippingThreshold,
                'product_id_for_shipping' => $id_product
            ]);
        }
        
        return '';
    }

    /**
     * AJAX endpoint for getting shipping cost
     */
    public function getShippingCostInfo($id_product)
    {
        header('Content-Type: application/json');
        
        $shippingCost = $this->getShippingCost($id_product);
        
        echo json_encode([
            'success' => true,
            'shipping_cost' => $shippingCost,
            'formatted_cost' => number_format($shippingCost, 2, ',', ' ') . ' zł'
        ]);
        exit;
    }

    /**
     * Get shipping cost for product from PrestaShop delivery system
     */
    private function getShippingCost($id_product)
    {
        try {
            $db = Db::getInstance();
            $product = new Product($id_product);
            
            if (!$product->id) {
                return $this->getFallbackShippingCost(null);
            }
            
            // Get ADDITIONAL shipping costs
            $additionalShippingCost = (float)$product->additional_shipping_cost;
            
            $weight = (float)$product->weight;
            $productPrice = Product::getPriceStatic($id_product, true);
            
            // Simpler query - check if product has assigned carriers
            $productCarriersQuery = 'SELECT d.price AS delivery_price, c.name AS carrier_name
                FROM '._DB_PREFIX_.'carrier c
                INNER JOIN '._DB_PREFIX_.'product_carrier pc ON pc.id_carrier_reference = c.id_reference
                INNER JOIN '._DB_PREFIX_.'delivery d ON d.id_carrier = c.id_carrier
                WHERE pc.id_product = '.(int)$id_product.'
                  AND c.active = 1
                  AND c.deleted = 0
                  AND d.id_zone = 1
                  AND d.price > 0
                ORDER BY d.price ASC';
            
            $result = $db->getValue($productCarriersQuery);
            
            if ($result && $result > 0) {
                // IMPORTANT: Add 23% VAT to database price + additional costs
                $basePrice = (float)$result * 1.23;
                $additionalPrice = $additionalShippingCost * 1.23;
                return $basePrice + $additionalPrice;
            }
            
            // If no assigned carriers, check general carriers
            $generalCarriersQuery = 'SELECT d.price AS delivery_price, c.name AS carrier_name
                FROM '._DB_PREFIX_.'carrier c
                INNER JOIN '._DB_PREFIX_.'delivery d ON d.id_carrier = c.id_carrier
                WHERE c.active = 1
                  AND c.deleted = 0
                  AND d.id_zone = 1
                  AND d.price > 0
                ORDER BY d.price ASC';
            
            $generalResult = $db->getValue($generalCarriersQuery);
            
            if ($generalResult && $generalResult > 0) {
                // IMPORTANT: Add 23% VAT + additional costs
                $basePrice = (float)$generalResult * 1.23;
                $additionalPrice = $additionalShippingCost * 1.23;
                return $basePrice + $additionalPrice;
            }
            
            // Fallback to weight-based system (already includes additional_shipping_cost)
            return $this->getFallbackShippingCost($product);
            
        } catch (Exception $e) {
            return $this->getFallbackShippingCost(new Product($id_product));
        }
    }
    
    /**
     * Get fallback shipping cost based on product weight (old system)
     */
    private function getFallbackShippingCost($product)
    {
        if (!$product || !$product->id) {
            return 30.75; // 25 net * 1.23 VAT
        }
        
        $weight = (float)$product->weight;
        $additionalShippingCost = (float)$product->additional_shipping_cost;
        $additionalShippingCostWithVat = $additionalShippingCost * 1.23;
        
        if ($weight > 5.0) {
            return 151.29 + $additionalShippingCostWithVat; // 123 net * 1.23 VAT - Heavy products
        } elseif ($weight > 2.0) {
            return 37.82 + $additionalShippingCostWithVat; // 30.75 net * 1.23 VAT - Medium products  
        } else {
            return 30.75 + $additionalShippingCostWithVat; // 25 net * 1.23 VAT - Light products
        }
    }
    
    /**
     * Get default shipping cost (simple approach)
     */
    private function getDefaultShippingCost()
    {
        try {
            $db = Db::getInstance();
            
            // Very simple query - get lowest delivery cost
            $defaultQuery = '
                SELECT MIN(price) as min_price
                FROM '._DB_PREFIX_.'delivery 
                WHERE price > 0
            ';
            
            $defaultCost = $db->getValue($defaultQuery);
            
            if ($defaultCost && $defaultCost > 0) {
                return (float)$defaultCost;
            }
        } catch (Exception $e) {
        }
        
        // Ostateczny fallback
        return 25.0;
    }
}