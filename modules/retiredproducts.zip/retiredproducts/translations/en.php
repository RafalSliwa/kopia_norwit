<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{retiredproducts}prestashop>retiredproducts_1'] = 'Retired product:';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_2'] = 'Reference number:';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_3'] = 'Product withdrawn';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_4'] = 'Availability';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_5'] = 'This product is no longer available for sale.';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_6'] = 'An alternative product with comparable parameters is available, carefully selected by our specialists.';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_7'] = 'Alternative:';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_8'] = 'Product available';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_9'] = 'See more';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_10'] = 'net';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_11'] = 'gross';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_12'] = 'suggested product';
