<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{retiredproducts}prestashop>retiredproducts_cb80d044ce8b2174681b0642bbd93267'] = 'Menedżer wycofanych produktów';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_0edea6589c4eaacf308ed8ed2e6d9575'] = 'Dodaje flagę oznaczającą produkty jako wycofane i wyświetla niestandardowy szablon.';
$_MODULE['<{retiredproducts}prestashop>retiredproducts_f62dedad685b570f499b61e94084dab2'] = 'Wycofany';
$_MODULE['<{retiredproducts}prestashop>product-retired_3dd42bfc8345e82c43b4a40a3426ec49'] = 'Indeks';
$_MODULE['<{retiredproducts}prestashop>product-retired_3feac9110ec1753c9fdd74220d49cdc5'] = 'produkcja została zakończona';
$_MODULE['<{retiredproducts}prestashop>product-retired_faeaec9eda6bc4c8cb6e1a9156a858be'] = 'Dostępność';
$_MODULE['<{retiredproducts}prestashop>product-retired_e30aeb0a94169da3aa968ec0ac5ae31d'] = 'Produkt wycofany';
$_MODULE['<{retiredproducts}prestashop>product-retired_80d889c08e270f0016d61b963e13fec1'] = 'Ten produkt nie jest już dostępny w sprzedaży.';
$_MODULE['<{retiredproducts}prestashop>product-retired_b04c99a5518f98a0abb1f231216ba0ba'] = 'Dostępny jest alternatywny produkt o porównywalnych parametrach, starannie wyselekcjonowany przez naszych specjalistów.';
$_MODULE['<{retiredproducts}prestashop>product-retired_0d6a7e7ac305e41f42698835329bd203'] = 'nowy model';
$_MODULE['<{retiredproducts}prestashop>product-retired_923524e0ff0364df2987d3b8269f03d1'] = 'Produkt dostępny';
$_MODULE['<{retiredproducts}prestashop>product-retired_6cccaabdfde6cd41475727341f2fcfbe'] = 'netto';
$_MODULE['<{retiredproducts}prestashop>product-retired_891ad007e2e9f2d55be6669cd9abc7a0'] = 'Zobacz więcej';
$_MODULE['<{retiredproducts}prestashop>product_tab_95b76d5e3994480c97b2f5fd743c6985'] = 'Produkt wycofany ze sprzedaży.';
$_MODULE['<{retiredproducts}prestashop>product_tab_93cba07454f06a4a960172bbd6e2a435'] = 'Tak';
$_MODULE['<{retiredproducts}prestashop>product_tab_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nie';
$_MODULE['<{retiredproducts}prestashop>product_tab_da1106849f30e7317855ad8b87c00a7a'] = 'Przekieruj do produktu. Wyszukaj i wybierz produkt zastępczy.';
$_MODULE['<{retiredproducts}prestashop>product_tab_b04d8826e12a1a13bbdd427644e7de90'] = 'Szukaj według nazwy lub indeksu';
$_MODULE['<{retiredproducts}prestashop>product_tab_e47706fb90b5cf259d2119db94553da3'] = 'Aktualny identyfikator przekierowanego produktu:';
$_MODULE['<{retiredproducts}prestashop>product_tab_60e9457f23097c648b54737cd3cdd1db'] = 'Aktualna nazwa produktu przekierowania:';
$_MODULE['<{retiredproducts}prestashop>product_tab_c6a97e7e5cd6b7cb77992bf51ea227c7'] = 'Aktualny indeks produktu przekierowania:';
