<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once dirname(__FILE__) . '/../../config/config.inc.php';

header('Content-Type: application/json');

try {
    $db = Db::getInstance();

    $id = isset($_GET['id']) ? (int)$_GET['id'] : 2681;
    $settings = $db->getRow('SELECT * FROM ' . _DB_PREFIX_ . 'customcarrier_product WHERE id_product = ' . (int)$id);
    $name = $db->getValue('SELECT name FROM ' . _DB_PREFIX_ . 'product_lang WHERE id_product = ' . (int)$id . ' AND id_lang = 1');

    echo json_encode([
        'id_product' => $id,
        'name' => $name,
        'settings' => $settings
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    echo json_encode([
        'error' => true,
        'message' => $e->getMessage()
    ], JSON_PRETTY_PRINT);
}
