<?php if(!isset($is_template)) die(); ?>
<?php
//EndDiv
?>
</div>
