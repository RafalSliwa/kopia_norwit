<?php

namespace DhlAssistant\Core\Interfaces;

interface ICanBeCloned
{
}

?>