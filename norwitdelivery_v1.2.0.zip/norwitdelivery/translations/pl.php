<?php

global $_MODULE;
$_MODULE = array();

// Admin controller
$_MODULE['<{norwitdelivery}prestashop>adminnorwitdeliverycontroller_8cf04a9734132302f96da8e113e80ce5'] = 'Zaktualizowano %d produktów.';

// Bulk edit template
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_a1b5f0e9f214d5ab94f76cc1f3f8e8f7'] = 'Edycja zbiorcza - Czas dostawy';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_category'] = 'Kategoria';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_all_categories'] = 'Wszystkie kategorie';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_manufacturer'] = 'Producent';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_all_manufacturers'] = 'Wszyscy producenci';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_stock'] = 'Stan';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_all_products'] = 'Wszystkie produkty';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_out_of_stock_only'] = 'Tylko brak w magazynie';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_search'] = 'Szukaj';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_name_or_reference'] = 'Nazwa lub indeks';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_filter'] = 'Filtruj';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_apply_same_text'] = 'Zastosuj ten sam tekst do wszystkich zaznaczonych produktów:';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_example_delivery'] = 'np. Dostawa 14 dni';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_select_all'] = 'Zaznacz wszystkie';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_deselect_all'] = 'Odznacz wszystkie';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_id'] = 'ID';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_name'] = 'Nazwa';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_reference'] = 'Indeks';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_delivery_time_text'] = 'Tekst czasu dostawy';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_no_products_found'] = 'Nie znaleziono produktów';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_save_changes'] = 'Zapisz zmiany';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_showing'] = 'Wyświetlam';
$_MODULE['<{norwitdelivery}prestashop>bulk_edit_products'] = 'produktów';

// Module main file
$_MODULE['<{norwitdelivery}prestashop>norwitdelivery_display_name'] = 'Norwit Delivery - Czas dostawy';
$_MODULE['<{norwitdelivery}prestashop>norwitdelivery_description'] = 'Wyświetla tekst z pola "Etykieta gdy brak w magazynie" dla produktów niedostępnych.';
